# C5G7 Parameter Matching — OpenMC Pilot

Date: 2026-10-11

## Determination
The supplied `c5g7-run/2d/build-xml-2d.py` and `benchmarks/c5g7/openmc/2d/build-xml-2d.py` are identical in the checked source content. The generated pilot input retains the same 2-D 3×3 assembly lattice, 7-group MGXS library, dimensions, source region, and mixed symmetry/leakage boundaries. This is consistent with the C5G7 2-D quarter-core layout (2×2 fuel assemblies with an L-shaped water reflector), rather than an arbitrary custom 3×3 full-core loading.

## Matched model parameters

| Parameter | Reference builder | Pilot inputs | Assessment |
|---|---|---|---|
| Energy treatment | Multi-group | Multi-group | Match |
| Group structure | `logspace(-5, 7, 8)` → 7 groups | MGXS file has 7 groups | Match |
| Core lattice | 3×3: `[[UO2, MOX, reflector], [MOX, UO2, reflector], [reflector, reflector, reflector]]` | Same lattice in `geometry.xml` | Match |
| Assembly pitch | 21.42 cm | 21.42 cm | Match |
| Core extent | −32.13 to +32.13 cm in x and y | Same | Match |
| Pin lattice | 17×17, 1.26 cm pitch | Same in geometry | Match |
| Source box | `[-32.13, -10.71, -1]` to `[10.71, 32.13, 1]`, fissionable only | Same coordinates, fission-only source | Match |
| Boundary conditions | x-min reflective; x-max vacuum; y-min vacuum; y-max reflective | Same in geometry XML | Match to supplied benchmark builder |
| Cross-section file | `mgxs.h5` | Same SHA-256 in source and run_01: `170cc799f496e952465583bb078b2a88eae0f09886a821fd7ee8999d1eb93216` | Exact file match |
| Reference-builder run settings | 20,000 batches; 500 inactive; 10,000 particles/batch | Pilot: 100 batches; 20 inactive; 1,000 particles/batch | **Not matched; pilot is low-statistics only** |

## Eigenvalue comparison

Reported pilot results:

- Run 1: `k_eff = 1.1835467599894272`, reported within-run standard deviation `0.0026622798480468862`.
- Run 2: `k_eff = 1.186434171360614`, reported within-run standard deviation `0.0029585381830072375`.
- Run 3: `k_eff = 1.189520560287838`, reported within-run standard deviation `0.0029163647503847015`.
- Arithmetic mean: `1.1865004972126263`.
- Sample SD across three run estimates: `0.00298745239967223`.
- C5G7 2-D reference value used for comparison: approximately `1.18655`.
- Mean difference from reference: `-0.0000495027873737` (about `-0.00417%`).

The mean is numerically very close to the reference value, and the difference is much smaller than the observed across-run spread. This is encouraging evidence of consistency with the reference eigenvalue, but the pilot is not a complete validation study: the runs use far fewer histories than the builder's prescribed settings, only three seeds are available, and the spread is relatively large. Do not report this as converged/fully validated until the production-statistics run and convergence/source diagnostics are completed.

## Parameter corrections required for a production validation run

1. Use the reference builder's settings as the first production target: `particles=10000`, `batches=20000`, `inactive=500`. Do not silently change the geometry or MGXS library while increasing statistics.
2. Preserve the existing pilot directory. Never run a script that deletes `stage34_runs/run_01..run_03` before copying the pilot outputs elsewhere.
3. Use new output paths for production runs, unique recorded seeds, input hashes, and captured `openmc.log` files.
4. Inspect source convergence/entropy history and `k_eff` by batch; ensure inactive batches are sufficient rather than assuming 500 is automatically enough.
5. Compare the production `k_eff` and uncertainty with the exact C5G7 reference definition used by the project, and report the difference in pcm as well as relative percent.
6. Verify spatial tallies against the corresponding benchmark reference distribution if the paper makes flux/power-distribution claims. Eigenvalue agreement alone does not validate all tallies.

## Execution boundary
The current analysis environment does not have the OpenMC Python module or executable, so no new OpenMC transport calculation was run here. This report matches input parameters and analyzes the supplied pilot outputs; it does not fabricate a production rerun.

## Sources
- OECD/NEA C5G7 benchmark description and 2-D/3-D exercises: https://www.oecd-nea.org/science/wprs/eg3drtb/
- OECD/NEA C5G7-TD background and relation to the steady-state C5G7 model: https://www.oecd-nea.org/science/wprs/egrts/c5g7-td/
- C5G7 reference value cross-check (secondary implementation description): https://github.com/EmreSakarya/c5g7-2d-transport-benchmark

# CB-PFR / QUBO / OpenMC Deep Audit — v0.4.5

Date: 2026-10-11

## Scope and honesty statement
This package is a software and evidence audit, not nuclear-safety certification. Software tests can validate implementation behavior; they cannot validate a reactor model or certify a fuel loading. The supplied project does not include a verified mapping from the Usmanov QUBO variables to the 3×3 U/M/W assembly-pattern interface. Consequently, no end-to-end claim that a Usmanov QUBO solution was physically evaluated is warranted yet.

## New defect fixed
The prior `scripts/rank_results.py` silently omitted a configured physical constraint when either its metric column was absent. This bypassed the fail-closed behavior implemented in `cbpfr.rank_candidates`. The CLI now raises a clear error for a configured, bounded constraint with missing column definitions or missing data columns, before writing ranked output. Regression tests cover this behavior and the no-limits warning path.

## Code/test verification performed in this environment
- Unit/integration tests: see `AUDIT_RESULTS.txt` for exact current output.
- Python compileall: see `AUDIT_RESULTS.txt`.
- ZIP integrity: checked after packaging.
- Candidate ranking is operational and lexicographic; `mean ± z·uncertainty` is not automatically a calibrated confidence interval.
- Classical simulated annealing remains a classical heuristic, not quantum annealing and not a global-optimality certificate.

## QUBO mapping audit result: BLOCKED BY MISSING ARTIFACTS, NOT BY SOFTWARE
A valid verification needs the actual QUBO coefficient matrix (or BQM), variable order, encoding/decoding, constraint definitions and penalty weights, plus a known small instance with independently computed energies. These are not present in the CB-PFR adapter package. Without them, energy equality and constraint-preservation cannot be established. The adapter's U/M/W patterns are only a software interface, not evidence of the intended Usmanov encoding.

## OpenMC model audit observations
- The builder defines a 3×3 arrangement of UO2/MOX/reflector assemblies; this is a specific custom configuration, not automatically the C5G7 benchmark loading.
- The boundary conditions are mixed (x-min reflective, x-max vacuum, y-min vacuum, y-max reflective). This may be intentional, but must be justified from the intended benchmark/symmetry domain.
- The builder source sets a much larger run (20,000 batches, 500 inactive, 10,000 particles) than the pilot runner settings (100 batches, 20 inactive, 1,000 particles). Pilot results must not be presented as converged benchmark results.
- The supplied three-seed pilot estimates are approximately 1.183547, 1.186434, and 1.189521, with arithmetic mean 1.1865005 and between-run sample SD 0.00298745. This is a repeatability snapshot for one input model, not a comparison of candidate fuel configurations. The spread alone does not prove a model is wrong; benchmark setup and convergence must be checked.
- The candidate runner rewrites the lattice assignment in the builder. This changes the physical model, but the scientific validity of each allowed pattern is not established by parser validation.
- Never rerun scripts that delete old run directories without first archiving results; the packaged candidate runner now refuses existing candidate output directories, but the separate legacy `run_stage34_fixed.py` should also be treated as destructive until manually revised.

## Benchmarking/CB-PFR evidence boundary
The synthetic benchmark can test ranking logic and statistical behavior only. It cannot establish nuclear physical validity. A defensible comparison should use identical candidate pools and report feasibility rate, objective quality among feasible candidates, runtime/evaluation budget, seed-wise uncertainty, and failure cases for at least: QUBO-energy-only selection, best-feasible oracle (only as a reference upper bound), uniform-margin screen, point-estimate screen, CB-PFR screen, and random selection. Report ablation by removing uncertainty margins and by varying z, scales, and weights. Keep oracle results clearly labeled as unavailable to a real decision-maker.

## Required external execution before physical claims
1. Verify the intended C5G7 benchmark variant, symmetry, boundaries, assembly inventory, axial geometry, and source distribution against the reference specification.
2. Run mesh/tally and eigenvalue convergence checks (particles, inactive batches, batches, source convergence) on the Mac's OpenMC installation.
3. Verify each QUBO-derived candidate maps to a physically permitted loading and that the generated geometry actually reflects it.
4. Run multiple seeds per candidate and compare candidate differences against Monte Carlo uncertainty.
5. Archive input/output hashes and logs without overwriting earlier results.

## Research claim wording recommended
“CB-PFR is a post-optimization, uncertainty-aware candidate screening/ranking layer evaluated on synthetic data and a pilot OpenMC model; the supplied evidence does not yet establish benchmark-validated fuel-management performance or a validated QUBO-to-assembly mapping.”

## Additional final-pass finding (2026-10-11)
The default `config.json` previously contained a `keff` entry with both `lower` and `upper` set to null. The CLI skipped that entry, but the configuration misleadingly looked like a configured physical constraint. The default configuration has now been changed to an empty `physical_constraints` object and an explicit warning note. This prevents a placeholder from being mistaken for a physical acceptance criterion. The sample `data/candidates.csv` contains only its header (zero candidates), so the CLI smoke test correctly emits a zero-row result and a warning; this is not an experimental benchmark.

## Current verified checks after final-pass change
- `pytest -q`: 13 passed.
- `python -m compileall -q .`: exit 0.
- CLI smoke test on the shipped candidate template: exits successfully, writes a zero-row CSV, and warns that no physical bounds are configured.
- The empty candidate template is not evidence of solver performance; a real solver export is still required.

# CB-PFR Integrated Pipeline v0.4.1 — hardening notes

## Changes
- Candidate output directories are no longer recursively deleted on rerun. The runner stops with an actionable message if a candidate directory already exists; use a new `--out` directory to preserve earlier runs.
- Added SHA-256 provenance for source model inputs and per-candidate generated inputs/statepoint where available.
- Added Python version and platform to run metadata.

## Verification
- `python -m pytest -q`: 6 passed.
- `python -m compileall -q .`: passed.

## Scientific limitations (unchanged)
- This is a candidate-runner/integration scaffold, not proof of a validated QUBO-to-C5G7 mapping.
- Do not interpret synthetic benchmarks or unverified candidate encodings as reactor-physics validation.
- OpenMC execution was not performed as part of this hardening pass; run it collaboratively on the user's configured Mac/OpenMC environment and verify the model, cross sections, and benchmark conditions before interpreting keff.

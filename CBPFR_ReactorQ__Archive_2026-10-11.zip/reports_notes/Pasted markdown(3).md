Aku sudah membaca kedua PDF dan menjalankan beberapa pencarian literatur. Pencariannya terbatas (sekitar enam kueri, dan satu sumber penting, OSTI untuk Fustero et al., tidak bisa dibuka isi lengkapnya), jadi tidak ada bagian di bawah yang boleh dibaca sebagai "belum pernah ada yang melakukannya". Temuan paling penting ada di bagian pertama, karena memengaruhi seluruh sisanya.

## 0. Temuan kritis pada Paper A

**Masalah utama: E_QUBO konstan pada semua solusi layak.** Dari Pers. (13)–(18) Usmanov, H = H⁽¹⁾+…+H⁽⁵⁾ hanya terdiri atas suku penalti kuadrat atau perkalian biner nonnegatif. Tidak ada fungsi objektif. Jadi H ≥ 0, dan H = 0 (setelah konstanta dari ekspansi kuadrat dibuang) untuk setiap konfigurasi layak. Quantum annealing di sini adalah *sampler himpunan layak* F, bukan pencari "solusi terbaik". Akibatnya:

- Pers. (3) Paper A mencatat E_QUBO untuk solusi valid. Nilainya sama untuk semua solusi valid, sehingga korelasi E_QUBO dengan k_eff tidak terdefinisi. Tujuan 3 ("apakah konfigurasi optimal secara matematis juga sesuai pada simulasi") kosong, karena tidak ada solusi yang "optimal matematis" selain "layak".
- Metrik TTS Usmanov (Pers. 21–22) adalah time-to-*feasible*-solution, bukan time-to-optimum.
- Usmanov sendiri menyebut bahwa menambahkan reaktivitas dan fluks ke model QUBO adalah penelitian lanjutan. Jadi arah Paper A sejalan dengan *future work* mereka, dan kebaruannya tidak bisa diklaim besar.

**Masalah lain, berurutan menurut keparahan:**

1. Abstrak dan Bab III menyebut "quantum annealing", tetapi seluruh komputasi dijalankan di MacBook M1. Itu simulated annealing atau solver quantum-inspired. Gunakan istilah yang jujur.
2. Gambar 5 dan 6 tampak seperti keluaran simulasi, padahal Bab IV menyatakan simulasi belum dijalankan. Beri label "ilustrasi konseptual" langsung pada gambar, bukan hanya di teks.
3. Pers. (9): dengan encoding one-hot, d_H menghitung tiap sel yang berbeda dua kali. Gunakan d_H/2, yaitu jumlah sel dengan tipe rakitan berbeda.
4. Pers. (8): P(s)=nₛ/M tidak informatif kalau |F| besar, karena hampir semua run menghasilkan konfigurasi unik. Pakai probabilitas tabrakan Σp² atau entropi, ditambah estimasi massa yang belum terlihat (Good–Turing).
5. Pers. (6): pada peta 2D, P_max/P_avg adalah peaking radial. Simbol F_q biasanya dipakai untuk faktor kanal panas total 3D.
6. Belum ada model material untuk tiga kelas burnup, geometri sel 13, kode transport, kriteria konvergensi, atau satuan Δk (pcm) beserta ketidakpastian Monte Carlo. Tanpa itu Δk antar-run tidak bisa ditafsirkan.
7. Catatan sumber: di teks Usmanov yang kamu unggah, kendala (6) diberi label aturan (i) dan (7) aturan (ii), padahal isinya tertukar terhadap daftar aturan. Cek dengan versi arXiv asli sebelum mengutip.

Perbaikan struktural yang sama dengan yang sudah kamu terima di proyek QUBO-mu: tambahkan suku objektif H_obj dari proxy fisik. Tanpa itu Paper A tidak punya pertanyaan yang bisa dijawab.

## A. Peta literatur (hanya yang terverifikasi sesesi ini)

| Sumber                                                                                                                                                                         | Mekanisme                                                                                                                                        | Hubungan                                                         |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------- |
| [Usmanov et al., arXiv:2308.13348](https://arxiv.org/abs/2308.13348) / [J. Phys.: Conf. Ser. 2701, 012031](https://iopscience.iop.org/article/10.1088/1742-6596/2701/1/012031) | QUBO untuk pola pemuatan ulang, dibandingkan lewat quantum annealing, simulated annealing, dan algoritma quantum-inspired                        | Dasar. Penalti saja, tanpa fisika                                |
| [PHYSOR 2020, EPJ Web Conf.](https://www.epj-conferences.org/articles/epjconf/pdf/2021/01/epjconf_physor2020_06028.pdf)                                                        | Aturan heuristik pemuatan PWR dikodekan ke model surrogate untuk quantum annealer, lalu pola dievaluasi dengan kode fisika                       | **Pendahulu langsung** dari "evaluasi solusi QUBO dengan fisika" |
| [Fustero, Mueller, Kropaczek, Farrelly, ANS Trans. 126, 756–759 (2022)](https://doi.org/10.13182/T126-37875)                                                                   | Fungsi biaya diperluas dengan boron kritis awal dan biaya bahan bakar; PSA, QGA, dan QA dibandingkan; surrogate Ising dilatih dari pola kandidat | Pendahulu langsung, dengan objektif fisik                        |
| [Kitai et al., PRR 2, 013319 (2020)](https://link.aps.org/pdf/10.1103/PhysRevResearch.2.013319)                                                                                | Factorization machine sebagai regresi yang bisa ditulis sebagai QUBO, lalu diminimalkan quantum annealer secara iteratif (FMQA)                  | Mekanisme surrogate-QUBO generik                                 |
| [Review BBO dengan factorization dan Ising machine, arXiv:2507.18003](https://arxiv.org/html/2507.18003)                                                                       | Ulasan FMQA dan variannya                                                                                                                        | Peta metode turunan FMQA                                         |
| ["Harnessing Inferior Solutions…", arXiv:2404.16784](https://arxiv.org/html/2404.16784)                                                                                        | Memakai QUBO deterministik dengan parameter nilai harapan, lalu mencari solusi paling robust di keluaran stokastik annealer                      | Dekat sekali dengan kontribusi "reliabilitas"                    |
| [Optimum-Preserving QUBO Parameter Compression, arXiv:2307.02195](https://arxiv.org/pdf/2307.02195)                                                                            | Rentang dinamis parameter QUBO memengaruhi ketahanan terhadap distorsi pada hardware                                                             | Relevan untuk perturbasi koefisien                               |

Belum kuverifikasi sendiri: Li–Wang–Ding (NED 397, 111950), Lucas (2014), Glover et al. (2019). Ketiganya kuambil dari daftar pustaka kedua paper. Teori optimisasi robust (Ben-Tal–Nemirovski, Bertsimas–Sim) dan literatur model pengganti nuklir lain di luar yang tertera di atas juga belum kutelusuri.

Dampak ke kebaruan: gagasan "surrogate QUBO + validasi kode fisika" sudah ada di PHYSOR 2020 dan Fustero 2022. Kebaruan harus dicari di pertanyaan yang lebih sempit.

## B. Kandidat celah

| #  | Celah                                                                                                                                          | Bukti                                                                                          | Risiko duplikasi                 | Kelayakan M1                         |
| -- | ---------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- | -------------------------------- | ------------------------------------ |
| G1 | Penalti-saja = sampler F. Seberapa seragam annealer menyampel F, dan apa dampaknya pada distribusi respons fisik?                              | Kuat (Pers. 13–18 langsung dari paper)                                                         | Tidak diketahui; belum kutemukan | Tinggi (6.435 pola mentah di sel 13) |
| G2 | **Seberapa kuadratik respons fisik pada F?** Fraksi varians k_eff dan peaking yang bisa ditangkap model kuadratik biner, plus regret surrogate | Tidak langsung; kedua pendahulu memakai surrogate, tetapi tidak kulihat ukuran keterwakilannya | Sedang                           | Tinggi                               |
| G3 | Alokasi anggaran evaluasi fisik (active learning)                                                                                              | Pendahulu kuat (FMQA)                                                                          | Tinggi                           | Sedang                               |
| G4 | Ketahanan terhadap perturbasi koefisien                                                                                                        | Pendahulu ada (2404.16784, 2307.02195)                                                         | Tinggi                           | Tinggi                               |
| G5 | Penentuan bobot penalti λ yang terjamin                                                                                                        | Usmanov memakai bobot satuan; literatur tutorial ada                                           | Tinggi, novelty rendah           | Tinggi                               |

## C. Rekomendasi arah

**G2, dengan G1 sebagai prasyaratnya.** Alasannya: G2 menguji asumsi yang selama ini diterima begitu saja (bahwa respons neutron cukup kuadratik untuk dikodekan ke QUBO), pertanyaannya sempit, bisa dijawab *eksak* di sel 13 lewat enumerasi, dan hasil negatif pun tetap hasil. G3–G5 punya pendahulu yang terlalu dekat. G4 tetap bisa jadi bagian sekunder, tetapi jangan klaim sebagai kebaruan.

Bukti untuk G2 belum cukup untuk menyebutnya "celah yang terbukti". Pencarianku tidak menemukan ukuran seperti itu, tetapi itu bukan bukti ketiadaan.

## D. Penurunan matematis

**Definisi.** F ⊂ {0,1}^{3N} adalah himpunan layak dari Pers. (4)–(9) Usmanov. Untuk z ∈ F, kode fisika Φ memberi y(z) = (k_eff, F_ΔH) (dihitung, bukan dipelajari). U_F adalah distribusi seragam pada F.

**Ukuran keterwakilan.** Untuk respons skalar f dan P_d himpunan polinomial berderajat ≤ d dalam x:

$$\rho_d(f)=\frac{\min\_{g\in P_d}\mathbb E\_{U_F}\big[(f-g)^2\big]}{\mathrm{Var}\_{U_F}(f)}=1-R^2_d .$$

ρ₂ adalah fraksi varians yang *tidak* bisa ditangkap QUBO. Karena one-hot membuat monomial saling bergantung pada F, ambil solusi norma minimum atau gunakan ridge. Estimasi ρ_d dengan cross-validation yang dikelompokkan per orbit simetri, supaya pola yang ekuivalen secara simetri tidak bocor antara data latih dan uji.

**Hipotesis H1 (belum terbukti).** Teori perturbasi orde satu memberi δk ≈ ⟨φ†,(δF − kδA)φ⟩/⟨φ†Fφ⟩, yang linear terhadap perubahan komposisi lokal, sehingga ρ₂(k_eff) diharapkan kecil. Namun pertukaran segar↔terbakar adalah perubahan besar, jadi suku orde tinggi mungkin tidak ignorable. Peaking adalah maksimum atas rakitan (non-mulus), jadi ρ₂(F_ΔH) diharapkan lebih besar. Ini bisa salah, dan itulah gunanya diuji.

**Proposisi 1 (diturunkan; elementer dan kemungkinan sudah dikenal).** Jika sup_F |f − f̂| ≤ ε dan ẑ meminimalkan f̂, maka f(ẑ) − min f ≤ 2ε. Bukti: f(ẑ) ≤ f̂(ẑ)+ε ≤ f̂(z\*)+ε ≤ f(z\*)+2ε.

**Proposisi 2 (diturunkan; idealisasi).** Misalkan p_β ∝ e^{−βf} dan p̂\_β ∝ e^{−βf̂}. Karena e^{−βf̂} ∈ e^{−βf}·[e^{−βε}, e^{βε}], rasio normalisasi Ẑ/Z ∈ [e^{−βε}, e^{βε}], sehingga |log(p̂\_β/p_β)| ≤ 2βε dan KL(p̂‖p) ≤ 2βε. Batas ini hanya berlaku jika annealer menyampel Boltzmann pada suhu efektif β, dan itu asumsi yang diketahui sering tidak terpenuhi. Batas sup-norm juga pesimistis. Versi L² yang lebih bermakna masih terbuka.

Yang belum terbukti: hubungan ρ₂ dengan regret *tanpa* asumsi sup-norm, dan perilaku pada core besar.

## E. Algoritma (nama sementara: RepQ)

**Input:** geometri, N_b, F, solver fisika Φ, anggaran evaluasi B, ambang τ.

1. **Bangun F.** Sel 13: enumerasi (batas atas 13!/(8!·4!·1!) = 6.435 pola mentah sebelum kendala). Core lebih besar: sampling dengan SA yang objektif linear acaknya diganti-ganti, untuk memperluas cakupan.
2. **Evaluasi** n ≤ B pola dengan Φ.
3. **Fit** model derajat 1, 2, 3 (ridge/lasso), hitung ρ̂\_d lewat CV per-orbit.
4. **Aturan berhenti.** Jika ρ̂₂ > τ, laporkan "QUBO surrogate tidak memadai untuk respons ini" dan selesai.
5. **Bangun QUBO.** Jika ρ̂₂ ≤ τ: H = H_pen(λ) + μ·f̂₂, dengan λ lebih besar dari variasi maksimum f̂ agar pelanggaran tidak menguntungkan (syarat penalti standar).
6. **Solve** M run SA, evaluasi top-k yang berbeda dengan Φ, hitung regret terhadap optimum hasil enumerasi.

**Kompleksitas:** fitur berpasangan p = O((3N)²), untuk N=13 sekitar 741. Fit biaya O(np²) per model. Dominasi biaya ada pada Φ, bukan pada fit.

**Yang baru vs standar:** semua komponen (surrogate-QUBO, ridge/CV, SA) standar. Yang berpotensi baru hanyalah ukuran ρ_d pada F Usmanov dan aturan berhenti berbasis ρ̂₂. Itu *tidak cukup* untuk menyebutnya algoritma baru. Ini kerangka diagnostik.

## F. Audit kebaruan

| Komponen                             | Terdekat                                                      | Perbedaan matematis                     | Kategori     | Ketidakpastian            |
| ------------------------------------ | ------------------------------------------------------------- | --------------------------------------- | ------------ | ------------------------- |
| Surrogate kuadratik dari data fisika | FMQA; PHYSOR 2020; Fustero 2022                               | Tidak ada                               | 1            | Rendah                    |
| Ukuran ρ_d pada F                    | Analisis Walsh/ANOVA umum; belum kutemukan untuk fuel loading | Diterapkan pada F hasil kendala one-hot | 2, mungkin 3 | Tinggi, belum cukup bukti |
| Aturan berhenti berbasis ρ̂₂         | Model selection standar                                       | Tipis                                   | 2            | Sedang                    |
| Batas regret (Prop. 1–2)             | Argumen sup-norm klasik                                       | Tidak ada                               | 1            | Rendah                    |
| Analisis sampler terhadap F          | Belum kutemukan                                               | Belum jelas                             | 5            | Tinggi                    |

## G. Rancangan eksperimen

- **Benchmark:** sel 13 (8/4/1, dari Tabel 1 Usmanov; tata letak sel perlu kamu definisikan). Lalu sel 37 (16/17/4) dengan sampling.
- **Fisika:** solver difusi 2-grup 2D buatan sendiri (iterasi daya, NumPy), dengan konstanta grup dari satu benchmark PWR publik. Pilih dan verifikasi sumbernya sendiri, aku belum memeriksa konstanta apa pun sesesi ini. Difusi deterministik, jadi ρ̂ tidak tercampur derau Monte Carlo. Klaim "transport" di Paper A tidak bisa dipertahankan kalau yang dipakai difusi. Ubah istilahnya.
- **Pembanding:** (a) sampling acak dari F; (b) SA penalti-saja (basis Usmanov); (c) **SA dengan Φ langsung dalam loop pada anggaran Φ yang sama** (ini pembanding terpenting); (d) surrogate derajat 1 dan 3 sebagai ablasi.
- **Metrik:** ρ̂\_d untuk k_eff dan F_ΔH, Kendall τ dan top-k recall surrogate terhadap urutan sejati, regret persentil, jumlah evaluasi Φ. Ulangi tiap SA ≥ 30 seed dan laporkan sebaran, bukan nilai terbaik.
- **Hipotesis terbantah jika:** ρ̂₂ > 0,3 untuk kedua respons, atau regret surrogate-guided tidak lebih baik dari SA langsung pada anggaran sama. Ambang 0,3 itu usulanku, tetapkan sebelum melihat data.
- **Keterbatasan:** sel 13 adalah mainan, dan hasilnya tidak otomatis berlaku pada teras nyata. Tidak ada klaim keselamatan reaktor.

## H. Rencana implementasi (SMA, Python/C++, M1)

1. Enumerasi F sel 13 dengan backtracking dan cek terhadap QUBO penalti (H=0 ⇔ layak). Ini sekaligus memverifikasi Pers. 13–18.
2. Solver difusi 2-grup, divalidasi pada kasus analitik homogen (k\_∞).
3. Evaluasi seluruh F, hitung ρ_d. Ini hasil inti.
4. SA (neal) di QUBO penalti, ukur keseragaman sampling (G1).
5. Surrogate-QUBO dan pembanding (c). Lalu perluasan ke sel 37 bila waktu ada.

Semuanya klasik dan quantum-inspired. Tidak ada klaim keunggulan kuantum, dan hardware D-Wave tidak diperlukan.

## I. Rekomendasi akhir

1. **Masalah:** keterwakilan kuadratik respons fisik pada F, dengan G1 sebagai prasyarat.
2. **Mekanisme:** ρ_d, aturan berhenti ρ̂₂, dan analisis regret pada anggaran Φ yang sama.
3. **Pembeda:** hanya ukuran ρ_d pada F Usmanov plus uji regret yang adil. Sisanya standar.
4. **Bukti yang masih kurang:** pencarian literatur yang lebih lengkap (OSTI Fustero harus dibaca penuh, plus literatur surrogate nuklir lain), dan konfirmasi bahwa ρ_d tidak sudah dilaporkan di sana.
5. **Eksperimen minimum:** langkah 1–3 di atas pada sel 13.
6. **Dampak realistis:** panduan "kapan QUBO surrogate layak dipakai untuk fisika reaktor", bukan metode baru yang umum.
7. **Risiko terbesar:** ρ₂ ternyata besar (hasil negatif, tetap publikasi-layak sebagai studi kasus), atau Fustero 2022 sudah memuat analisis setara.
8. **Alternatif bila G2 sudah ada:** G1 (bias sampler pada himpunan layak) sebagai kontribusi utama, dengan G4 sebagai pendukung.

Kalau mau, aku bisa memasukkan ini ke Word/PDF seperti dokumen sebelumnya.
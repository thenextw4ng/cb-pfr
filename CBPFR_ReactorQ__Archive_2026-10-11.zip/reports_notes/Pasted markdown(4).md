## 1. Masalah yang dirumuskan

**Keputusan yang sebenarnya dihadapi** (ini yang belum dijawab FMQA maupun Fustero 2022, sejauh yang kuverifikasi): dengan anggaran B evaluasi fisik Φ, *kandidat mana yang layak dievaluasi, dan kapan boleh berhenti?* Model pengganti kuadratik hanya memberi peringkat. Ia tidak memberi alasan untuk berhenti atau untuk tidak mengevaluasi suatu kandidat.

**Variabel dan asumsi.**

- F ⊂ {0,1}^{3N}: himpunan layak dari Pers. (4)–(9) Usmanov. Untuk sel 13, F bisa dienumerasi.
- f: F → ℝ, nilai skalar dari Φ, yang diminimalkan. Contoh: f = F_ΔH + c·max(0, k_min − k_eff). Φ dihitung lewat simulasi, bukan dipelajari.
- f̂(z) = zᵀQ̂z + c₀: model pengganti kuadratik, dilatih dari data evaluasi.
- r(z) = f(z) − f̂(z): residual. Hanya sisi negatif yang berbahaya (lihat §2).
- D_tr: titik latih (boleh adaptif). D_cal: n_cal titik kalibrasi, diambil **seragam dari F**, terpisah dari D_tr, tidak dipakai melatih.
- α ∈ (0,1): toleransi. f_inc: nilai terbaik di antara semua titik yang sudah dievaluasi.

**Asumsi yang harus diperiksa:** (A1) titik kalibrasi benar-benar seragam pada F (mudah di sel 13, tidak otomatis di core besar), (A2) f̂ tidak bergantung pada D_cal, dan (A3) Φ deterministik (difusi, bukan Monte Carlo).

## 2. Penurunan

**Langkah A. Apa yang membuat keputusan "boleh berhenti" mustahil di FMQA.** Jika kita hanya tahu f̂ tanpa batas galat, tidak ada titik z yang bisa dikesampingkan secara bermakna.

**Langkah B. Informasi yang diperlukan.** Batas bawah f pada setiap z yang belum dievaluasi. Kalau ada q ≥ 0 dengan r(z) ≥ −q, maka

$$f(z);\ge;\underbrace{\hat f(z)-q}\_{\mathrm{LCB}(z)} .$$

Cukup satu sisi, karena z hanya perlu dievaluasi jika *mungkin lebih baik* dari yang sudah ada.

**Langkah C. Prinsip eliminasi.** Titik z hanya mungkin memperbaiki incumbent jika LCB(z) < f_inc, yaitu

$$f̂(z)<\tau:=f\_{\rm inc}+q .$$

Himpunan kandidat: C = {z ∈ F belum dievaluasi : f̂(z) < τ}.

**Langkah D. Dari mana q berasal.** Dua jalur, dan keduanya terkait ρ:

(i) *Split-conformal satu sisi.* Hitung s_i = −r(zᵢ) = f̂(zᵢ) − yᵢ pada D_cal. Ambil q sebagai elemen terurut ke-⌈(n_cal+1)(1−α)⌉ dari {sᵢ}, dipotong di 0. Jika indeks melebihi n_cal, q = +∞. Jika zᵢ dan titik baru Z seragam dan independen dari f̂, maka P(r(Z) ≥ −q) ≥ 1−α.

(ii) *Rumus perencanaan dari ρ.* Jika f̂ adalah proyeksi L² pada U_F dengan intercept, residual berrata-rata nol dan E[r²] = ρ₂·Var_U(f). Pertidaksamaan Cantelli memberi P(r < −t) ≤ σ_r²/(σ_r²+t²). Dengan t=q ini bernilai α bila

$$q\_{\rm Cantelli}=\sqrt{\rho_2,\mathrm{Var}\_U(f)};\sqrt{\tfrac{1-\alpha}{\alpha}} .$$

Ini bebas distribusi tetapi konservatif, dan hanya berlaku sebagai aproksimasi untuk ridge yang dilatih pada sampel hingga. Fungsinya bukan menggantikan (i), melainkan **memprediksi ukuran |C| sebelum membayar evaluasi kalibrasi**.

**Langkah E. Alternatif sederhana.** q = 0 (pakai f̂ murni) adalah FMQA tanpa aturan berhenti. Untuk q konstan, urutan prioritas LCB identik dengan urutan f̂. **Jadi kontribusi mekanisme ini ada pada eliminasi dan penghentian, bukan pada urutan pemilihan.** Itu kuakui terbuka: kalau yang dicari adalah urutan pemilihan yang lebih baik, ini bukan jawabannya.

**Langkah F. Uji ekstrem.**

- ρ₂ → 0: q → 0, C menyusut ke ≈ {argmin f̂}, mekanisme berhenti cepat.
- ρ₂ besar: q besar, C ≈ F∖evaluated, algoritma turun menjadi enumerasi penuh. Ini bukan kegagalan sistem, melainkan sinyal bahwa QUBO tidak layak untuk respons itu.
- n_cal < ⌈1/α⌉ − 1: q = ∞, tidak ada eliminasi.
- Kalibrasi tidak seragam: jaminan hilang (§7).

**Langkah G. Audit kebaruan.** Ada di §8.

## 3. Mengapa formula ini memengaruhi keputusan

Ia menentukan tiga hal yang tidak ditentukan FMQA:

1. **Siapa yang tidak dievaluasi:** semua z dengan f̂(z) ≥ f_inc + q.
2. **Kapan berhenti:** C kosong.
3. **Kapan mengganti model:** jika |C| yang diprediksi dari ρ̂\_d (d = 2 vs 3, lewat q_Cantelli) melebihi sisa anggaran, naikkan derajat atau hentikan dan laporkan. Aturan ini heuristik, bukan teorema.

Di sinilah ρ_d berfungsi sebagai alat keputusan, bukan hanya diagnostik.

## 4. Input, output, pembaruan, penghentian

- **Input:** orakel F (cek kelayakan, sampel seragam, enumerasi bila kecil), Φ, n₀, n_cal, α, b (ukuran batch), B (anggaran total, *termasuk* n_cal dan n₀), M (jumlah pembacaan annealing), μ, λ, d.
- **Output:** incumbent z̄, status ∈ {CERTIFIED, BUDGET}, q akhir, |C| tersisa, jumlah panggilan Φ.
- **Pembaruan:** refit f̂ pada D_tr (ridge, kekuatan dipilih lewat CV di D_tr), hitung ulang q dari D_cal, perbarui f_inc dan τ.
- **Penghentian:** C kosong (CERTIFIED), atau anggaran habis (BUDGET).
- **Penanganan kendala:** H = λ·H_pen + μ·zᵀQ̂z. Jika λ > μ·Σ\_{i≤j}|Q̂ᵢⱼ|, setiap keadaan melanggar punya energi lebih tinggi daripada keadaan layak mana pun. Ini syarat cukup yang kasar, karena tiap kendala yang dilanggar menyumbang ≥ 1 pada H_pen. Nilai sebesar itu bisa merusak rentang dinamis annealer (cf. arXiv:2307.02195), jadi praktisnya pakai λ lebih kecil dan filter kelayakan pasca-sampling.

Pseudocode lengkap ada di blok akhir.

## 5. Contoh numerik kecil

**Catatan: angka di bawah rekaan ilustratif untuk memperlihatkan mekanisme, bukan hasil eksperimen.** F = {A,…,F}, meminimalkan f. Anggap q = 0,5 sudah dikalibrasi dan benar untuk satu sisi.

| Titik | f̂  | f (benar) | r = f−f̂ | LCB = f̂−0,5 |
| ----- | --- | --------- | -------- | ------------ |
| A     | 0,0 | 0,8       | +0,8     | −0,5         |
| B     | 0,3 | 0,2       | −0,1     | −0,2         |
| C     | 0,6 | 0,1       | −0,5     | 0,1          |
| D     | 1,0 | 1,2       | +0,2     | 0,5          |
| E     | 1,4 | 1,5       | +0,1     | 0,9          |
| F     | 2,0 | 2,3       | +0,3     | 1,5          |

Evaluasi awal acak: E (f=1,5), jadi f_inc = 1,5.

- Ronde 1: C = {LCB < 1,5} = {A,B,C,D} (F ditolak, LCB = 1,5 tidak < 1,5). Evaluasi A → 0,8.
- Ronde 2: LCB < 0,8 → {B,C,D}. Evaluasi B → 0,2.
- Ronde 3: LCB < 0,2 → {C}. Evaluasi C → 0,1.
- Ronde 4: LCB < 0,1 → ∅. **Berhenti**, dengan 4 panggilan Φ (E,A,B,C) dan optimum C ditemukan.

**Pembanding FMQA dengan anggaran tetap:** urutan f̂ adalah E, A, B, C, D, F. Anggaran 3 → menghasilkan 0,2 (tidak menemukan C). Anggaran 4 → menemukan C tetapi tidak tahu harus berhenti, jadi bisa lanjut sampai 6 panggilan.

**Perbedaannya jujur sempit:** urutan pemilihan sama, yang berbeda adalah D dan F tidak perlu dievaluasi dan ada alasan formal untuk berhenti. Dengan q konstan, tidak ada kemampuan pencarian baru.

## 6. Sifat matematis

**Teorema 1 (terbukti, deterministik).** Jika algoritma berhenti dengan C kosong, dan V = {z : r(z) < −q} (menggunakan f̂ dan q final), maka {z : f(z) < f_inc} ⊂ V.

*Bukti.* Jika z belum dievaluasi, f(z) < f_inc, dan z ∉ V, maka f̂(z) ≤ f(z)+q < f_inc+q = τ, jadi z ∈ C, bertentangan dengan C kosong. Jika z sudah dievaluasi, f(z) ≥ f_inc menurut definisi incumbent. ∎

*Akibat:* peringkat z̄ ≤ 1 + |V|.

**Teorema 2 (terbukti dengan syarat kuat).** Jika f̂ dilatih hanya pada data independen dari D_cal dan D_cal seragam i.i.d. dari F, maka E|V| ≤ α|F|, sehingga peringkat yang diharapkan ≤ 1 + α|F| (rata-rata atas D_cal).

Syarat ini benar persis hanya pada **satu putaran** dengan f̂ dilatih dari desain acak.

**Yang belum terbukti dan merupakan kelemahan nyata:**

- Pada putaran berikutnya, titik latih dipilih memakai q yang dihitung dari D_cal, jadi f̂ final bergantung pada D_cal dan jaminan konformal tidak lagi sah secara ketat. Versi ketat membutuhkan kalibrasi segar per refit (mahal). Pada sel 13 ini bisa **diuji secara empiris**, karena F lengkap diketahui dan |V| bisa dihitung langsung.
- Annealer tidak bisa mensertifikasi bahwa C kosong. Pada sel besar "C kosong" hanya berarti "M pembacaan tidak menemukan kandidat". Sertifikat sungguhan memerlukan enumerasi atau solver eksak.
- Jaminan marjinal terhadap α|F| titik, bukan terhadap optimum. Optimum adalah titik ekstrem dan residualnya cenderung paling negatif (efek seleksi), jadi bisa saja berada di V. Teorema 1–2 hanya membatasi *peringkat*, bukan menjamin optimum.
- q global (homoskedastik). Residual di daerah f̂ rendah kemungkinan lebih besar, sehingga LCB bisa terlalu optimistis tepat di tempat yang penting.
- Sampling seragam pada F untuk core besar tidak mudah. SA penalti-saja menghasilkan sampel yang bias (inilah G1), dan itu langsung merusak asumsi A1.

## 7. Perbandingan dengan metode terdekat

| Komponen                                      | Terdekat                                                                                 | Penilaian                                                    |
| --------------------------------------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------ |
| Surrogate QUBO + annealer iteratif            | FMQA (Kitai 2020); FMIRA untuk batch                                                     | Sama, tidak baru                                             |
| Batas bawah (LCB) dan eliminasi kandidat      | Pendekatan LCB/racing/successive elimination, dan pre-screening di EA berbantu surrogate | **Kemungkinan besar dikenal; belum kuverifikasi sesesi ini** |
| Kalibrasi q lewat split-conformal             | Prediksi konformal (metode standar)                                                      | Standar; aplikasinya ke BBO berbasis QUBO belum kutelusuri   |
| Annealer sebagai kueri "ada z dengan f̂ < τ?" | Pengambilan sampel energi rendah dari annealer secara umum                               | Penggunaan ini wajar, bukan mekanisme baru                   |
| Hubungan q ↔ ρ₂ lewat Cantelli                | Ketaksamaan standar                                                                      | Turunan elementer                                            |
| Pada himpunan layak Usmanov dengan Φ difusi   | PHYSOR 2020, Fustero 2022                                                                | Domain sama, mekanisme berhenti tidak kulihat di snippet     |

**Kesimpulan terbuka:** ini kemungkinan besar setara dengan "FMQA + pruning berbasis interval prediksi + aturan berhenti", kombinasi yang mungkin sudah ada di literatur surrogate-assisted optimization yang tidak sempat kutelusuri. Jangan ditulis sebagai "algoritma baru".

## 8. Eksperimen pembanding (anggaran Φ identik)

- **Benchmark:** sel 13 (8/4/1), F dienumerasi penuh, optimum dan seluruh peringkat diketahui. Lalu sel 37 dengan sampel (tanpa sertifikat eksak).
- **Φ:** solver difusi 2-grup 2D buatan sendiri (deterministik), skalar f = F_ΔH + penalti k_eff.
- **Metode:** (a) RCE-Q; (b) FMQA tanpa q dan tanpa aturan berhenti; (c) SA langsung dengan Φ dalam loop; (d) acak dari F; (e) RCE-Q dengan kalibrasi segar per refit.
- **Anggaran:** total panggilan Φ, *termasuk* n_cal dan n₀ pada (a) dan (e). Ini wajib, kalau tidak (a) tampak lebih murah secara curang.
- **Pengulangan:** ≥ 30 seed per metode, laporkan median dan sebaran.
- **Metrik:** peringkat riil incumbent (kuantil terhadap F), panggilan Φ saat berhenti, cakupan empiris P(r ≥ −q), |V|, ukuran |C| per ronde, apakah ρ̂ memprediksi |C|.

## 9. Penilaian jujur

Mekanisme ini layak diimplementasikan dan layak diuji, tetapi **belum dapat diklaim sebagai kebaruan**. Yang terbukti hanya implikasi deterministik (Teorema 1) dan elementer. Tidak ada hasil eksperimen apa pun, dan angka di §5 hanyalah ilustrasi.

## Blok akhir

### Formula utama kandidat algoritma (RCE-Q: Residual-Calibrated Elimination with QUBO threshold query)

Model pengganti: f̂(z) = zᵀQ̂z + c₀, dilatih ridge dari fitur [1, zᵢ, zᵢzⱼ].

Galat satu sisi: sᵢ = f̂(zᵢ) − yᵢ pada D_cal.

$$q=\max!\Big(0,;s\_{(\lceil (n\_{\rm cal}+1)(1-\alpha)\rceil)}\Big),\qquad \tau=f\_{\rm inc}+q,$$

$$C={z\in F\setminus\mathcal E:\ \hat f(z)<\tau},$$

dengan 𝓔 himpunan titik yang sudah dievaluasi. Evaluasi hanya anggota C dengan f̂ terkecil. Henti jika C = ∅.

Rumus perencanaan: q_Cantelli = √(ρ₂ Var_U f)·√((1−α)/α).

### Pseudocode lengkap

```
function RCE_Q(F, Phi, n0, n_cal, alpha, b, B, M, mu, lam, d=2, seed=0):
    # F: .is_feasible(z), .sample_uniform(k, rng), .enumerate() (hanya core kecil)
    # Phi(z) -> skalar f(z) (deterministik)
    rng <- RNG(seed)
    Z_cal <- F.sample_uniform(n_cal, rng)                    # seragam
    Z_tr  <- F.sample_uniform(n0, rng)  tanpa duplikat dengan Z_cal
    y_cal <- [Phi(z) for z in Z_cal];  y_tr <- [Phi(z) for z in Z_tr]
    calls <- n_cal + n0
    E <- set(Z_cal) ∪ set(Z_tr)

    loop:
        # (1) fit
        feat(z) <- [1] ++ [z_i] ++ [z_i*z_j for i<j]          # d=2
        w <- ridge_fit(feat(Z_tr), y_tr), kekuatan via K-fold CV pada D_tr
        Qhat <- pack(w): Qhat[i][i] = w_i ; Qhat[i][j] = w_ij (i<j); c0 = w_0
        fhat(z) <- z^T Qhat z + c0

        # (2) kalibrasi satu sisi
        s <- sort([ fhat(z) - y for (z,y) in zip(Z_cal, y_cal) ])
        k <- ceil((n_cal+1)*(1-alpha))
        q <- INF if k > n_cal else max(0, s[k-1])

        # (3) incumbent dan ambang
        f_inc <- min(y_tr ++ y_cal);  tau <- f_inc + q

        # (4) kueri ambang
        if F kecil:  C <- {z in F.enumerate() : z not in E, fhat(z) < tau}
        else:
            H(z) <- lam*H_pen(z) + mu*(z^T Qhat z)
            reads <- SA(H, M)                                  # beberapa jadwal suhu
            C <- unique{z in reads : F.is_feasible(z), z not in E, fhat(z) < tau}
        if |C| = 0:  return (incumbent, "CERTIFIED", q, 0, calls)  # sah hanya jika enumerasi eksak
        if calls >= B: return (incumbent, "BUDGET", q, |C|, calls)

        # (5) pilih
        batch <- b elemen C dengan fhat terkecil (tie: max-min jarak Hamming)
        batch <- batch[: B - calls]
        y_b <- [Phi(z) for z in batch]
        Z_tr += batch;  y_tr += y_b;  E += batch;  calls += |batch|

```

### Perbedaan matematis dari metode terdahulu

Terhadap FMQA: tidak ada perbedaan di surrogate maupun urutan prioritas (untuk q konstan). Perbedaannya hanya pada **aturan pemangkasan dan penghentian** berbasis batas galat satu sisi yang dikalibrasi. Terhadap literatur eliminasi atau konformal: kemungkinan setara atau modifikasi kecil.

### Bukti yang tersedia dan yang dibutuhkan

**Tersedia:** Teorema 1 (deterministik), Teorema 2 (satu putaran, syarat independensi), dan batas Cantelli.

**Dibutuhkan:** cakupan empiris pada kalibrasi yang dipakai ulang, pengujian heteroskedastisitas di daerah f̂ rendah, perbandingan dengan metode pruning surrogate yang sudah ada (perlu penelusuran literatur lebih luas), dan hasil eksperimen apa pun.

### Eksperimen yang dapat menggugurkan hipotesis

Hipotesis dianggap gugur jika salah satu terjadi pada sel 13 dengan ≥ 30 seed:

1. Cakupan empiris P(r ≥ −q) turun jauh di bawah 1−α setelah putaran ke-2.
2. Total panggilan Φ RCE-Q (termasuk n_cal) tidak lebih sedikit daripada FMQA tanpa aturan berhenti pada kuantil peringkat yang sama.
3. Kuantil peringkat incumbent melebihi α pada mayoritas seed.
4. ρ̂₂ tidak memprediksi |C| secara monoton.
5. Kalibrasi segar (e) tidak lebih baik dari yang dipakai ulang (menandakan tak ada masalah dependensi, atau sebaliknya jika jauh lebih baik).

Ambang numerik (misalnya "jauh di bawah") perlu kamu tetapkan *sebelum* melihat data.

### Penilaian jujur tentang kebaruan dan kelayakan

**Kebaruan:** kategori 2 (komponen dikenal, kombinasi baru), kemungkinan besar tidak naik ke kategori 3. Belum cukup bukti untuk mengklaim lebih. Pencarianku terbatas, dan literatur eliminasi atau konformal di BBO kemungkinan sudah memuat hal serupa.

**Kelayakan:** tinggi. Sel 13 punya paling banyak 6.435 pola mentah, difusi 2-grup ringan, n_cal + n₀ ≈ 40–100 panggilan Φ, dan semuanya berjalan di M1 tanpa hardware kuantum.

**Nilai ilmiah realistis:** bukan metode optimisasi baru, melainkan studi terkontrol tentang kapan surrogate QUBO boleh dipercaya untuk memutuskan evaluasi fisik. Hasil negatif (ρ₂ besar → C ≈ F) tetap temuan yang sah.
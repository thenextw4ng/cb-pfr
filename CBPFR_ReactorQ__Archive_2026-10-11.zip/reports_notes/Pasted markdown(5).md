Kesimpulan ringkasnya: celah umum ("keputusan lebih baik dengan surrogate yang tidak sempurna") **sudah ditangani sebagian oleh metode yang sudah ada**, dan kebaruan tidak bisa diklaim. Yang bertahan adalah satu pertanyaan sempit yang bisa diuji murah. Seluruh isi di bawah belum didukung hasil eksperimen apa pun. Pencarian literatur hari ini mencakup BOCS, KG berkorelasi, conformal BO, dan elimination bandit. Ranking-aware surrogate, DRO, dan multi-fidelity belum kutelusuri. Item dari pengetahuan umum yang belum kuverifikasi sesesi ini kutandai.

## 1. Executive verdict

**Celah umum: tidak terbukti belum terselesaikan.**

- Keputusan evaluasi berbasis surrogate kuadratik-QUBO dengan ketidakpastian sudah dibahas di BOCS (Thompson sampling).
- Nilai informasi atas pemilihan akhir sudah dibahas di knowledge gradient.
- Jaminan cakupan untuk model yang salah spesifikasi sudah dibahas di conformal BO.

**Celah sempit yang tersisa (belum terbukti kosong):** apakah *amplop batas bawah residual yang bersifat lokal dan deterministik*, yang dibangun dari residual yang diukur tepat pada titik yang sudah dievaluasi, mengeliminasi dan menghentikan pencarian lebih baik daripada aturan Bayesian atau conformal pada anggaran simulasi yang sama? Jawabannya bergantung pada satu besaran fisik yang bisa diukur eksak pada sel 13 (konstanta Lipschitz residual).

**Rekomendasi: revise.** Lanjutkan sebagai studi metodologis terbatas yang diawali satu pra-uji sehari. Jangan klaim algoritma baru.

## 2. Audit RCE-Q (terverifikasi secara internal)

**Benar:**

- Teorema 1 (terminasi dengan C kosong membatasi peringkat oleh |V|) tetap sah, karena murni deterministik.
- Untuk q konstan, urutan prioritas LCB sama dengan urutan f̂, sehingga **q hanya mengubah retensi, bukan peringkat**.

**Klaim tidak sah atau terlalu kuat:**

1. **Kuantil split-conformal bukan batas global deterministik.** Ia menjamin cakupan marginal atas (D_cal, Z), bukan pada kumpulan titik yang justru dipilih oleh optimizer, yaitu ekor bawah f̂.
2. **C kosong bukan sertifikat optimalitas global** kecuali F dienumerasi dan batasnya valid.
3. **SA tidak bisa menyatakan C kosong.** "Tidak ada pembacaan yang memenuhi f̂<τ" berarti pencarian tidak menemukan, bukan bahwa tidak ada.
4. **Kalibrasi yang dipakai ulang setelah refit adaptif tidak lagi valid**, karena f̂ dan pemilihan titik bergantung pada D_cal.
5. **Ketaksamaan Cantelli** menuntut residual berrata-rata nol dengan varians σ² pada titik baru. Ridge pada sampel hingga melanggar keduanya, dan ρ₂·Var adalah residual proyeksi populasi, bukan galat di luar sampel. Perlakukan sebagai heuristik perencanaan.
6. **Biaya kalibrasi lupa dihitung:** agar q berhingga pada tingkat α, perlu n_cal ≥ ⌈1/α⌉−1 (α=0,05 → ≥19 evaluasi fisik per kalibrasi). Dengan kalibrasi segar setiap refit, biaya ini berulang.

**Belum terselesaikan:** perilaku di ekor bawah f̂ (lihat §5).

## 3. Tinjauan literatur berbasis mekanisme

| Metode                                                                   | Keputusan yang diambil                                                                                                                                                                            | Jaminan                                                                                | Gagal bila                                                                                          |
| ------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| **BOCS** (Baptista & Poloczek, ICML 2018)                                | Surrogate kuadratik dengan regresi Bayesian jarang, aturan Thompson sampling, acquisition diselesaikan dengan SA atau SDP ([ref 1](http://proceedings.mlr.press/v80/baptista18a/baptista18a.pdf)) | Bukti empiris. Tidak ada aturan berhenti                                               | Interaksi orde tinggi, karena model terbatas pada interaksi orde rendah (catatan dari makalah lain) |
| **KG berkorelasi** (Frazier, Powell, Dayanik, INFORMS J. Comput. 2009)   | Nilai informasi dihitung lewat efeknya pada pemilihan akhir. Tersedia untuk belief linear dengan fungsi basis                                                                                     | Optimal tepat bila tersisa satu pengukuran, bukan optimal untuk anggaran multi-langkah | Noise dan prior salah spesifikasi                                                                   |
| **BO dengan prediksi konformal** (Stanton, Maddox, Wilson, AISTATS 2023) | Acquisition dengan set prediksi konformal; cakupan terjamin walau model salah spesifikasi, dengan koreksi pergeseran kovariat                                                                     | Cakupan marginal (dengan pembobotan)                                                   | Cakupan bersyarat pada titik terpilih                                                               |
| **LUCB / elimination** (Kalyanakrishnan dkk., ICML 2012)                 | Identifikasi lengan terbaik dengan batas kepercayaan bawah dan atas, jaminan PAC                                                                                                                  | PAC pada bandit noisy                                                                  | Tidak memakai surrogate parametrik                                                                  |
| **FMQA** (Kitai dkk., PRR 2020)                                          | Regresi factorization machine, dimodelkan sebagai QUBO, diminimalkan annealer                                                                                                                     | Tidak ada                                                                              | Tanpa batas galat atau penghentian                                                                  |
| Fustero 2022; PHYSOR 2020                                                | QUBO atau surrogate untuk pola pemuatan PWR yang divalidasi kode fisika (PHYSOR 2020)                                                                                                             | Tidak kulihat dari snippet                                                             | —                                                                                                   |

**Bukti yang belum bisa kuberikan:** apakah literatur surrogate-assisted EA dengan ranking-aware surrogate atau decision-focused learning mengalahkan pendekatan ini. Dari pengetahuan umum yang belum kuverifikasi: Lipschitz global optimization (Piyavskii/Shubert), LIPO, conformal Mondrian, jackknife+, no-good cuts, SPO+. Semuanya harus dicek sebelum klaim apa pun.

**Arah A–F, ringkas:**

- **A (ranking):** reversal pasangan diatur oleh selisih residual r(a)−r(b), bukan galat rata-rata. Ini mengarah ke C, bukan loss baru.
- **B (VoI):** KG dengan belief linear berbasis fungsi kuadratik sudah memuat ide ini. Redundansi tinggi.
- **C (struktur residual):** dipilih.
- **D (blind spot):** ada empat mode kegagalan. (1) Tidak dipilih surrogate: ditangani LB. (2) Tidak dibangkitkan annealer: tidak ada sertifikat, hanya status "tanpa sertifikat". (3) Dibangkitkan tetapi tidak dievaluasi: diselesaikan dengan pencatatan. (4) Dieliminasi dengan batas tidak valid: diaudit lewat asumsi regularitas.
- **E (pengulangan):** frekuensi kemunculan bukan probabilitas optimalitas yang terkalibrasi. Berguna paling banyak sebagai keragaman kandidat.
- **F:** ketegangan nyata, yaitu belief yang lebih kaya (menangkap residual) merusak sifat acquisition yang kuadratik, sehingga tidak lagi QUBO. Residual bersuku lokal berorde tinggi bisa direduksi ke QUBO dengan variabel bantu. Ada pekerjaan terkait pada [arXiv:2507.01389](https://arxiv.org/html/2507.01389), jadi ini bukan kebaruan.

## 4. Celah penelitian yang bisa difalsifikasi

**Pernyataan:** Untuk F berhingga (enumerable), f mahal dan deterministik, f̂\_t kuadratik-QUBO, dan residual r_t = f − f̂\_t yang diukur *tepat* pada E_t, apakah batas bawah f yang dibangun dari regularitas lokal residual memangkas F lebih banyak per evaluasi, tanpa menghilangkan optimum, dibandingkan (i) kuantil residual marginal (RCE-Q terkoreksi), (ii) Thompson sampling BOCS, dan (iii) KG dengan diskrepansi GP, pada anggaran evaluasi fisik B yang sama?

**Argumen tandingan terkuat:** KG atau BOCS dengan suku diskrepansi (kriging) memberi efek koreksi lokal yang sama secara probabilistik, dan Bayesian average-case memang optimal di bawah prior. **Jawabanku sebagian:** itu menghasilkan peringkat, bukan sertifikat berhenti, dan prior-nya dipertaruhkan pada surrogate yang salah spesifikasi. Itu *bukan* bantahan penuh, sehingga gap umum tidak kuklaim. Yang tersisa adalah pertanyaan empiris sempit di atas.

## 5. Garis keturunan (lineage)

**RCE-Q → keterbatasan terverifikasi → prinsip → ekstensi → teori → eksperimen.**

**Keterbatasan fundamental (dibuktikan lewat kontrak-contoh):** jaminan marginal tidak menjamin keputusan. Misalkan |F|=1000, r=0 di 990 titik, dan r=−5 di klaster 10 titik yang memuat optimum dengan f̂=8 sedangkan f\*=3. Dengan α=0,05 dan n_cal=100, kuantil ke-96 dari s=−r bernilai 0 dengan peluang sekitar 99,6% (hanya ≥5 titik klaster dari 100 yang membuatnya 5; P≈0,4%). Jadi q=0, τ=f_inc≈4, dan klaster dieliminasi. Cakupan marginal 99% ≥ 95% terpenuhi, Teorema 2 (E|V| ≤ α|F|) juga benar (10 ≤ 50), namun optimum ∈ V. **Ini bukan masalah penyetelan α**, karena α yang diperlukan bergantung pada massa klaster yang tidak diketahui.

**Prinsip:** setiap evaluasi mengungkap residual secara tepat pada satu titik. Jika residual memiliki regularitas lokal, titik itu memberi *batas deterministik yang bergantung lokasi* pada titik lain. Eliminasi dan seleksi sebaiknya memakai batas medan residual ini, bukan kuantil marginal.

## 6. Mekanisme dan penurunan

**Definisi.** Untuk z ∈ F (one-hot, N sel), jarak sel d(z,z′) = N − ⟨z,z′⟩ (jumlah sel dengan tipe berbeda). Residual r_t(z) = f(z) − f̂\_t(z), dengan f_lo batas bawah fisik yang diketahui (contoh: F_ΔH ≥ 1 secara definisi).

**Asumsi (R-L):** ∃L ≥ 0: |r(z)−r(z′)| ≤ L·d(z,z′) untuk semua z,z′ ∈ F.

**Derivasi.**

1. Dari (R-L), untuk titik terevaluasi zᵢ: r(z) ≥ rᵢ − L·d(z,zᵢ).
2. Karena f = f̂ + r: f(z) ≥ f̂(z) + rᵢ − L·d(z,zᵢ) untuk setiap i.
3. Ambil maksimum atas i dan gabungkan dengan f_lo:

$$\mathrm{LB}*t(z)=\max\Big(f*{lo},\ \hat f_t(z)+\max\_{i\in E_t}\big(r_i-L,d(z,z_i)\big)\Big).$$

4. Kandidat: C_t = {z belum dievaluasi : LB_t(z) < f_inc}. Pilih argmin LB atas C_t (bukan argmin f̂).

Ini mengubah dua keputusan: **siapa yang dievaluasi** (LB menyertakan koreksi residual lokal, bukan hanya f̂) dan **kapan berhenti** (C kosong).

**Catatan jujur:** ini adalah Piyavskii–Shubert pada medan residual (pengetahuan umum, belum kuverifikasi sesesi ini). Kebaruannya hanya pada penerapan ke residual surrogate QUBO dan perhitungan L eksak pada sel kecil.

## 7. Demonstrasi numerik

**Contoh A (manfaat; angka ilustratif, bukan eksperimen).** F = {z1…z7} pada garis dengan d=|i−j|, f_lo=1, L benar = 0,1.

f̂ = [3,0; 2,0; 2,5; 1,0; 2,8; 2,2; 3,5]. r = [0,0; 0,1; 0,2; 0,1; 0,0; −0,1; −0,2], jadi f = [3,0; 2,1; 2,7; 1,1; 2,8; 2,1; 3,3]. Optimum: z4 (1,1).

- Evaluasi awal 3 titik terendah f̂ (z4, z2, z6): r = 0,1; 0,1; −0,1. L̂ = maks kemiringan = max(0, 0,1, 0,05) = 0,1. f_inc = 1,1.
- LB: z1 = 3,0 + max(0,1−0,1; …) = 3,0; z3 = 2,5; z5 = 2,8; z7 = 3,5 − 0,2 = 3,3. Semua ≥ 1,1, jadi **C kosong setelah 3 evaluasi**.
- **FMQA-greedy** dengan B=4 memakai 4 evaluasi tanpa sertifikat. **RCE-Q** α=0,05 butuh n_cal ≥ 19 > |F|=7, jadi tidak bisa dijalankan. Keputusan yang berbeda hanyalah **penghentian**, bukan seleksi.

**Contoh B (tanpa manfaat atau gagal).** f̂ = [2,0; 1,8; 2,1; 2,4; 1,9; 2,2; 2,5], r = [0,1; 0,1; 0,0; −1,0; 0,0; 0,1; 0,1] (spike di z4), f = [2,1; 1,9; 2,1; 1,4; 1,9; 2,3; 2,6]. Optimum z4 (1,4), padahal f̂ memberi peringkat keenam.

- **L̂ terlalu kecil:** evaluasi awal z2, z5 memberi L̂ = 0,1/3 ≈ 0,033, sehingga LB(z4) = 2,4 + max(0,1−0,067; 0,0−0,033) ≈ 2,43 ≥ 1,9 dan **optimum dieliminasi**. Contoh nyata bahaya L̂ yang diestimasi dari sampel.
- **L benar = 1,0:** LB: z1=1,1; z3=1,2; z4=1,4; z6=1,2; z7=max(1; 2,5−2,0=0,5)=1,0. Tak satu pun ≥ f_inc=1,9. argmin LB = z7 (eksplorasi jauh), berbeda dari greedy f̂ yang memilih z1. Di sini tidak lebih baik (z7 f=2,6), dan sertifikat menuntut hampir enumerasi penuh.

## 8. Algoritma

```
function RCEQ_LRE(F, Phi, f_lo, B, n0, mode, L_mode, alpha, n_cal, gamma, b, refit_every, seed):
  # F: enumerate() (opsional), sample_uniform(k, rng), dist(z,zp)=N - dot(z,zp)
  # Phi(z) -> (y, ok)  ; ok=False bila simulasi gagal/tidak konvergen
  # mode in {"lre","conformal"} ; L_mode in {"oracle","estimated"}  (oracle hanya untuk studi kasus terbaik)
  rng <- RNG(seed); calls <- 0; E <- {}; FAIL <- {}
  procedure evaluate(z):
      (y, ok) <- Phi(z); calls <- calls + 1          # gagal tetap dihitung
      if ok: E[z] <- y else: FAIL.add(z)
  if F punya nol anggota layak: return (None, NO_FEASIBLE)
  for z in F.sample_uniform(n0, rng): if calls < B: evaluate(z)
  if |E| = 0: return (None, SIM_FAILURE)
  t <- 0
  while calls < B:
      if t % refit_every == 0:
          fit f_hat dari E dengan ridge fitur derajat-2 ({1, z_i, z_i z_j}), regularisasi via LOO-CV
      Z_un <- F.enumerate() \ (E.keys ∪ FAIL)        # jalur enumerasi; jalur solver di bawah
      if Z_un kosong: return (best(E), TERMINATED_NO_CERT) bila bukan enumerasi penuh, else (best(E), CERTIFIED_EXACT)
      f_inc <- min(E.values())
      if mode = "conformal":
          if t % refit_every == 0:
              K <- sample_uniform(n_cal, rng) dari Z_un        # segar, tidak dipakai fit f_hat saat ini
              for z in K: if calls < B: evaluate(z)
              s <- sort([f_hat(z) - E[z] for z in K if z in E])
              k <- ceil((|s|+1)*(1-alpha))
              q <- INF jika k > |s| else max(0, s[k-1])
          C <- {z in Z_un : f_hat(z) < f_inc + q}; score <- f_hat
      else:  # "lre"
          r_i <- E[z_i] - f_hat(z_i) untuk z_i in E
          if L_mode = "oracle": L <- max_{z,zp in F, z!=zp} |(f(z)-f_hat(z)) - (f(zp)-f_hat(zp))| / dist(z,zp)  # perlu tabel penuh
          else: L <- gamma * max_{i<j} |r_i - r_j| / dist(z_i,z_j)   (INF bila |E|<2)
          LB(z) <- max(f_lo, f_hat(z) + max_i(r_i - L*dist(z,z_i)))
          C <- {z in Z_un : LB(z) < f_inc}; score <- LB
      if C kosong:
          if mode="lre" and L_mode="oracle": return (best(E), CERTIFIED_EXACT)      # valid hanya dalam studi benchmark
          else: return (best(E), TERMINATED_NO_CERT)
      batch <- b elemen C dengan score terkecil (seri: terjauh dari E)
      for z in batch: if calls < B: evaluate(z)
      t <- t + 1
  return (best(E), BUDGET)

# jalur non-enumerasi: C diperoleh dari solver (SA/annealer) atas H = lam*H_pen + mu*(z^T Qhat z)
# bila pembacaan tidak menghasilkan kandidat: status TERMINATED_NO_CERT, tidak pernah CERTIFIED_EXACT.

```

**Status:** `CERTIFIED_EXACT` hanya untuk enumerasi + `L_mode="oracle"` (batas atas manfaat, bukan penggunaan nyata). `TERMINATED_NO_CERT` untuk semua kasus lain termasuk annealer dan L terestimasi. `BUDGET`, `NO_FEASIBLE`, `SIM_FAILURE` sesuai namanya. Semua evaluasi (awal, kalibrasi, adaptif, gagal) masuk `calls`.

**Perbedaan dari RCE-Q:** dipertahankan fit f̂ kuadratik, struktur "eliminasi-lalu-berhenti", dan akuntansi anggaran. Diganti kuantil marginal q → amplop LB lokal. Aturan baru: argmin LB dan eliminasi LB ≥ f_inc.

## 9. Analisis teoretis

**Terbukti (bergantung (R-L) dengan L ≥ L benar):**

- **T1:** terminasi dengan C kosong ⇒ f_inc = min f. Bukti: untuk z belum dievaluasi, f(z) ≥ LB(z) ≥ f_inc.
- **T2:** LB_t tidak menurun terhadap t (maksimum atas himpunan yang bertambah), dan f_inc tidak naik, sehingga C_t menyusut monoton.
- **T3 (reduksi):** L=0 ⇒ setelah satu evaluasi f = f̂ + r₁ diketahui tepat. f̂≡0 ⇒ Lipschitz-optimization diskret. L=∞ ⇒ LB = f_lo, tidak ada eliminasi.
- **T4 (batasan fundamental):** tidak ada prosedur berbasis data berhingga yang bisa memastikan L. Untuk setiap L̂ dan data, ada f konsisten dengan data yang melanggar (R-L) lewat spike di titik yang tak terevaluasi (Contoh B).

**Belum terbukti, dan merupakan kelemahan nyata:**

- Audit konformal untuk kemiringan dengan batas gabungan |E|α hanyalah hipotesis kasarku.
- (R-L) berlaku untuk residual terhadap f̂\_t yang berubah tiap refit, sehingga L perlu dihitung ulang.
- Perilaku pada F besar yang tidak bisa dienumerasi tidak ada sertifikat.

**Kompleksitas** (enumerasi): pembaruan LB inkremental O(|F|·N) per evaluasi baru. L eksak O(|F|²·N) (sel 13: |F| ≤ 6.435 → \~4×10⁷ pasangan, layak).

## 10. Penilaian kebaruan

| Properti        | Usulan (LRE)                    | KG berkorelasi                          | BOCS                         | BO konformal                |
| --------------- | ------------------------------- | --------------------------------------- | ---------------------------- | --------------------------- |
| Keputusan       | argmin LB, eliminasi LB ≥ f_inc | maks nilai informasi atas pilihan akhir | Thompson sampling atas f̂    | maks acquisition konformal  |
| Informasi       | rᵢ eksak pada E                 | posterior mean dan kovarians            | posterior koefisien          | residual kalibrasi          |
| Aturan          | batas lokal deterministik       | KG = E[maks posterior baru] − maks lama | argmin sampel dari posterior | UCB/EI dengan set konformal |
| Anggaran        | dihitung tegas                  | satu langkah ke depan                   | iteratif                     | kalibrasi dihitung          |
| Galat model     | lewat L pada residual           | lewat kovarians                         | lewat posterior              | lewat kuantil               |
| Galat peringkat | dibatasi LB                     | implisit                                | implisit                     | implisit                    |
| Jaminan         | T1 bersyarat (R-L)              | optimal 1-langkah                       | tidak ada                    | cakupan marginal            |
| Keterbatasan    | L tak teridentifikasi           | prior, skalabilitas                     | orde rendah                  | cakupan marginal            |

**Jawaban:**

1. Ekuivalen secara matematis dengan metode yang ada? **Tidak persis, tetapi dekat.** Kemungkinan kategori 2.
2. Kasus khusus fungsi akuisisi mapan? Dalam hal efek koreksi lokal, KG dengan diskrepansi GP memberi efek serupa secara probabilistik.
3. Hanya beda domain? Sebagian: penerapan ke residual surrogate QUBO plus L eksak pada sel kecil.
4. Aturan keputusan berbeda secara nyata? Ya (deterministik, bersyarat asumsi), tetapi apakah cukup berarti belum diketahui.
5. Tantangan terkuat terhadap kebaruan: KG berkorelasi dengan basis kuadratik dan diskrepansi GP, serta BOCS.
6. **Status kebaruan: tidak terselesaikan.** Bukti yang meyakinkan reviewer skeptis: mengalahkan KG dan BOCS pada anggaran sama pada ≥2 benchmark.

## 11. Protokol eksperimen

**Pra-uji (sehari, putuskan lanjut atau batal):**

1. Enumerasi F sel 13, hitung f (F_ΔH, penalti k_eff) dengan solver difusi 2-grup.
2. Fit f̂ derajat-2, hitung **L eksak residual**.
3. Dengan L oracle dan n₀ titik acak, ukur fraksi F yang tereliminasi saat f_inc = f\*. **Batal bila retensi >50%** (ambang usulanku; tetapkan sebelum melihat data). Dalam kasus itu, hentikan: mekanisme tidak berguna di masalah ini.

**Eksperimen utama (hanya bila lolos pra-uji):**

- **Benchmark:** tabel lookup F sel 13 (ribuan seed murah), lalu sel 37 dengan sampling.
- **Baseline:** (a) RCE-Q terkoreksi, (b) BOCS-SA dari [repo resmi](https://github.com/baptistar/BOCS), (c) KG berkorelasi dengan basis kuadratik + residual GP (pada \~500 alternatif teratas, aproksimasi untuk biaya O(M²log M) yang berat), (d) LRE, (e) ablasi LRE tanpa surrogate (f̂≡0), (f) LRE dengan q global, (g) acak dari F.
- **Anggaran:** total panggilan Φ termasuk n₀, kalibrasi, adaptif, dan yang gagal. Prakehendaki B, kriteria berhenti, dan hasil primer.
- **Metrik:** regret terhadap optimum eksak, evaluasi untuk mencapai persentil target, P(optimum tereliminasi), kestabilan antar-seed (≥ 100 seed), selisih oracle vs estimated L, waktu.
- **Gugur bila:** (1) pra-uji gagal, (2) LRE tidak lebih baik dari KG atau BOCS pada anggaran sama, (3) manfaat hilang bila biaya estimasi L dihitung, (4) P(eliminasi optimum) dengan L̂ di atas α yang diharapkan, (5) hasil tidak konsisten antar-seed, (6) manfaat hanya pada tabel buatan khusus.
- **Keterbatasan:** solver difusi buatan sendiri bukan validasi reaktor, dan konstanta grup perlu dari sumber publik yang kamu verifikasi sendiri.

## 12. Rencana implementasi minimal

Hari 1: solver difusi dan enumerasi F (verifikasi H=0 ⇔ layak). Hari 1–2: f̂, L eksak, pra-uji. Hari 3–5 (jika lolos): lookup-simulator, lima baseline, 100 seed. Perangkat: numpy, scipy, scikit-learn, neal. Semua klasik dan quantum-inspired, tanpa hardware kuantum.

## 13. Dampak

- **Level 1 (aplikasi):** realistis.
- **Level 2 (metodologis):** mungkin, hanya bila mengalahkan KG dan BOCS pada ≥2 masalah.
- **Level 3:** tidak didukung. Rumusannya umum, tetapi buktinya tidak.

Pemakai punya alasan mengadopsi hanya bila residual surrogate halus (L kecil), evaluasi fisik mahal, dan ruang cukup kecil sehingga sertifikat berarti.

## 14. Rekomendasi akhir

**Revise, jangan abandon, jangan klaim baru.** Jalankan pra-uji sehari. Jika L eksak residual besar (retensi >50%), hentikan arah LRE dan pindah ke G1 (bias sampler pada F) sebagai kontribusi utama. Jika lolos, bandingkan lawan KG dan BOCS dengan akuntansi biaya yang jujur. Garis keturunan yang bisa dipertanggungjawabkan: **RCE-Q → keterbatasan marginal-vs-keputusan → medan residual → LRE → T1–T4 → pra-uji dan eksperimen yang bisa membatalkannya.**
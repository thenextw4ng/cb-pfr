# Stage 1 — Full Audit & Research Readiness Checklist

Date: 2026-10-10  
Baseline: ReactorQ Studio CB-PFR v1.1 archive  
Scope: static code/documentation audit and tests executed in the build environment. This is not a Mac runtime audit, physics validation, security certification, or independent peer review.

## A. Repository and software inventory

- [x] Archive extracted and file inventory reviewed (47 relevant Python/Markdown/JSON/CSV files counted by the audit command).
- [x] Python sources compiled with `python -m compileall -q .`.
- [x] Automated tests run: `pytest -q` → **23 passed**.
- [x] Packaged synthetic benchmark rerun with `python scripts/run_benchmark.py`.
- [x] Small QUBO solver spot-check compared with exhaustive enumeration for two 2- and 3-variable matrices; both sampled the exact optimum in this test. This is a spot-check, not a general optimality guarantee.
- [ ] Streamlit app smoke-tested on user's Mac / target environment.
- [ ] Dependency versions pinned in a lock file and clean-environment install tested.
- [ ] Full test coverage and mutation/property testing measured.

## B. Module status

| Module | Code present | Stage-1 finding | Gate status |
|---|---|---|---|
| UI / dashboard | Yes (`app.py`) | Streamlit layout and workflows exist; no target-Mac runtime smoke test in this audit. | Partial |
| QUBO solver | Yes (`solver.py`) | Local classical simulated annealing; input checks present; no optimality certificate; only tiny exhaustive spot-check done here. | Partial |
| QUBO validation | Partial | Matrix shape/finite-value checks exist. They do not validate scientific derivation, penalty strength, variable semantics, or physical encoding. | Blocked for science |
| Candidate mapping | Not established | UI U/M/W layouts are explicitly illustrative and no verified solution-vector-to-assembly/material mapping is included. | **BLOCKED** |
| CB-PFR ranking | Yes (`cbpfr.py`) | Lexicographic operational ranking with `mean ± z·uncertainty`; uncertainty and z are not automatically calibrated confidence intervals. | Partial |
| Physical evaluation | Yes (`physical_eval.py`) | Evaluates only user-provided metric bounds. Limits are not supplied or justified by default; this is not safety assessment. | Partial |
| Neutron backend discovery | Yes (`neutron_backend.py`) | Detects whether `scarabee` / `openmc` imports are available and labels validation “not assessed”. Discovery is not an executable Scarabée adapter. | **BLOCKED** |
| OpenMC runner | Yes (`openmc_runner.py`) | Runs an existing XML deck as-is and reads a statepoint if possible. It does not regenerate inputs to represent a UI candidate. | Partial / not end-to-end |
| Synthetic research evaluation | Yes (`research_eval.py`, `benchmark.py`) | Benchmark mechanics, Wilson intervals, sensitivity and conformal utilities exist; evidence applies to the synthetic data-generating process only. | Partial |
| Experiment tracking | Yes (`experiment_store.py`) | JSONL recorder exists; audit found no proof that every UI workflow automatically records complete provenance/hashes/environment. | Partial |
| Literature / manuscript | Yes (`docs/`, `manuscript/`) | Documents explicitly call the novelty audit preliminary. No systematic database search and no full novelty matrix evidenced. | Partial |

## C. Scientific claim audit

- [x] Synthetic benchmark is labelled `SYNTHETIC_NOT_PHYSICS` in output.
- [x] README explicitly says simulated annealing is classical, not quantum hardware.
- [x] README says UI patterns are illustrative and QUBO-to-assembly mapping is not verified.
- [x] README says OpenMC runs the selected input deck as-is, not UI candidates.
- [x] Documentation prohibits unsupported claims of physical validation, safety, state-of-the-art superiority, BRIN equivalence, or ISEF medal readiness.
- [ ] Named transport benchmark reproduced with versioned model and reference comparison.
- [ ] Numerical convergence demonstrated for the selected physical observables.
- [ ] Physical acceptance criteria justified by a specific benchmark/specification and preregistered before final comparison.
- [ ] Independent review of model assumptions and interpretation.

## D. Synthetic experiment reproduction

Command: `python scripts/run_benchmark.py`

Observed packaged benchmark summary:

| Method | Selected latent-feasibility rate | Mean selected objective | Trials |
|---|---:|---:|---:|
| QUBO-only | 0.4978 | -1.624275 | 5,000 |
| Point-estimate | 0.9602 | -1.230657 | 5,000 |
| CB-PFR | 0.9914 | -1.160616 | 5,000 |
| Uniform-margin | 0.9996 | -1.082621 | 5,000 |

Interpretation: in this generator, more conservative filtering increased selected latent-feasibility rate while worsening the selected objective. Uniform-margin outperformed CB-PFR on the primary synthetic feasibility rate, so the packaged result does **not** establish CB-PFR as the best method. The results cannot be generalized to reactor physics without physical benchmark evidence.

## E. Issues and risks found

### Critical blockers

1. **No end-to-end candidate-to-geometry/material mapping.** The QUBO output is not demonstrated to produce the actual model input used by the transport solver.
2. **No validated transport adapter.** `neutron_backend.py` performs backend discovery only; it does not implement a Scarabée transport workflow. The OpenMC runner executes an existing deck unchanged.
3. **No physical benchmark result in this package.** Therefore no reactor-physics accuracy or feasibility claim can be made.

### High-priority engineering/science work

4. The default uncertainty rule `mean ± z·u` is an operational screen unless `u` and `z` have justified statistical semantics. The UI/docs must preserve that distinction.
5. A missing candidate selection can still yield a first-row diagnostic ordering; callers must respect the explicit warning and never present it as a feasible selected candidate.
6. `experiment_store.py` provides a basic append-only JSONL recorder but does not by itself prove complete provenance, immutable artifacts, or automatic capture by every run path.
7. Solver tests should include property-based energy-delta correctness against brute force, deterministic replay, non-symmetric Q conventions, edge cases, and fair baseline tuning.
8. Physical evaluation requires careful tests for NaN/infinite/negative uncertainty and malformed limit values; acceptance logic should be hardened before use on reference results.
9. Literature audit is a curated starting point, not a systematic search; originality remains unproven.
10. No clean installation or Streamlit interaction was executed on the target Mac in this audit.

## F. Stage-1 decision

**Stage 1 status: COMPLETED as a code/documentation audit; acceptance gates G1 correctness and G2 physics remain OPEN/BLOCKED.**

This means the audit and evidence inventory are documented. It does not mean the product passed scientific validation. Do not proceed to claims of physics validity or CB-PFR superiority until critical blockers 1–3 are addressed.

## G. Next stage entry criteria

Before Stage 2 can be marked complete:

- [ ] Choose a specific public benchmark and match its specification exactly.
- [ ] Define candidate variable encoding and prove round-trip mapping to model geometry/materials.
- [ ] Implement a backend adapter that writes/uses candidate-specific model inputs, records versions and hashes, and captures required tallies.
- [ ] Define observables, uncertainty treatment, and acceptance tolerances before seeing final results.
- [ ] Run at least one complete candidate-linked case and inspect logs/statepoint/tallies manually.
- [ ] Compare to independent reference results and document discrepancy/convergence.


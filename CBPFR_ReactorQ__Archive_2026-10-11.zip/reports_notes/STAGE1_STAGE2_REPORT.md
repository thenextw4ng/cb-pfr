# Stage 1/2 Completion Report

## Stage 1 — model/input audit

**Status: PASS WITH LIMITATIONS.** The five required input files are present and non-empty; `geometry.xml`, `materials.xml`, `settings.xml`, and `tallies.xml` parse as XML. The core lattice is a 3×3 array with four fuel positions in the upper-left 2×2 and five reflector positions. The model uses eigenvalue mode and multi-group energy mode.

Limitations found:

1. The package does not contain the baseline `statepoint.*.h5`, so its metadata, tally results, `k_eff`, and SHA-256 cannot be inspected here.
2. `materials.xml` references `/Users/catur/c5g7-work/c5g7-run/mgxs.h5`, a machine-specific path. `mgxs.h5` is present in this package, and candidate generation rewrites the path to the candidate-local copy.
3. Current `settings.xml` says 20 batches, 5 inactive, and 100 particles. Previously reported baseline metadata was 20,000 batches, 500 inactive, and 10,000 particles. Without the baseline statepoint and its original inputs, this mismatch cannot be resolved or attributed confidently.

## Stage 2 — six feasible candidate inputs

**Status: PASS — six input candidates generated and checked.** The generator enumerates all six 2-of-4 assignments. Each candidate has exactly two MOX universe entries (`11`) and two UO₂ entries (`9`) in the designated fuel positions. All five reflector positions remain universe `13`. Each candidate contains copies of all five required input files, candidate-local cross-section path, patched settings, and recorded SHA-256 hashes.

The QUBO cardinality penalty `E(x) = (sum(x_i) - 2)^2` has exactly six zero-energy binary vectors of length four, matching the enumerated candidates.

## Scope and claims

- No OpenMC simulation was run in this stage.
- The six candidates are feasible under the stated combinatorial/material-label constraints; this does not establish physical validity or optimality.
- No quantum annealer was run; enumeration exhaustively lists the feasible assignments.
- Baseline numerical statepoint audit remains pending receipt of the actual baseline statepoint and its matching input set.

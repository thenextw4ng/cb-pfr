# Stage 2 Checklist — Benchmark Selection

## Completed in this stage
- [x] Chosen the first reference problem: steady-state 2-D C5G7 neutron transport.
- [x] Documented why it is appropriate for an initial OpenMC transport verification effort.
- [x] Separated benchmark verification from the later QUBO optimization experiment.
- [x] Defined evidence gates B1–B6 and stop conditions.
- [x] Defined minimum run-provenance schema.
- [x] Recorded authoritative OECD/NEA source links.

## Still open — requires model/input inspection and actual transport runs
- [ ] Compare the actual input deck line-by-line with the authorized C5G7 specification (blocked: model deck absent from package).
- [ ] Verify and record nuclear-data provenance and cross-section library identity (blocked: library/provenance absent).
- [ ] Hash all actual model inputs and freeze a baseline manifest (preflight script added; actual inputs absent).
- [ ] Run settings/convergence study (pilot at one setting is not convergence).
- [x] Three-seed pilot recorded in `data/prior_pilot/stage34_results.csv` (pilot only; raw artifacts absent; not the final selected settings).
- [ ] Compare required benchmark observables against published reference (blocked until model/data/reference definition verified).
- [ ] Obtain independent review of benchmark compliance (not performed).

See `STAGE2_REMAINING_FIVE_AUDIT_v1.1.md` for the evidence-based status of the remaining five checks.

## Stage-2 decision
**Design gate passed; physics benchmark gate remains open.** Stage 3 must not claim verified candidate-to-physics integration until the baseline input model and run provenance are frozen and the benchmark-conformity review is complete.

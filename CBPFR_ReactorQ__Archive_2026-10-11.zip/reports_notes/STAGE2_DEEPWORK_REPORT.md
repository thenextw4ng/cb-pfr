# Stage 2 — Deepwork audit and resolution plan

## Executive decision
Existing C5G7-related artifacts were found in `c5g7-work-reviewed.zip`, including geometry/material/settings XML, `mgxs.h5`, `statepoint.20.h5`, `summary.h5`, and tally outputs. The work is therefore advanced beyond “no artifacts available.” This is an input/output audit, not yet physics validation.

## Completed in this pass
1. Located and extracted the existing reviewed C5G7 archive.
2. Parsed the XML inputs and recorded lattice dimensions, boundary surfaces, settings, file sizes, and SHA-256 hashes in `c5g7-work/c5g7-run/STAGE2_DEEP_AUDIT.json`.
3. Patched the *copied audit artifact only*: `materials.xml` now points to `./mgxs.h5` instead of an absolute user-specific path. The original ZIP was not modified.
4. Captured the known smoke-test result and limitations.

## Concrete findings
- Smoke-test result: `k_eff = 1.1369312061 ± 0.0163501854`; 20 total batches, 5 inactive, 100 particles. Treat as pipeline smoke test only.
- Geometry XML contains a 3×3 core lattice with UO2, MOX, and reflector assemblies; inner fuel lattices are 17×17. This structural observation alone does not establish full benchmark conformity.
- Core boundary planes are mixed reflective/vacuum. This must be checked against the exact benchmark case and symmetry assumptions.
- `materials.xml` previously used `/Users/catur/c5g7-work/c5g7-run/mgxs.h5`; portable relative path applied to the copy.
- The current audit runtime cannot import OpenMC, so a fresh run, convergence study, and independent reference comparison cannot honestly be claimed.

## Five previously open tasks — updated status
| Task | Result now | Remaining evidence required |
|---|---|---|
| Model vs benchmark spec | Partially audited structurally | Exact case/spec checklist, detailed dimensions/material/boundary comparison |
| Nuclear data provenance | File found; provenance not certified | Identify library origin, processing, group structure, checksums/source citation |
| Convergence and repeated seeds | Existing smoke output found; pilot insufficient | Run batch/particle convergence and independent seeds under adequate statistics |
| Reference comparison | Not performed | Use matching published reference quantity, case definition, uncertainty and tolerance |
| Independent review | Not performed | External reviewer or independently reproduced audit |

## Safe next execution protocol
1. On the machine/environment where OpenMC is installed and `mgxs.h5` is valid, run the copied model from its directory; first confirm the library is the intended seven-group C5G7 library.
2. Start with a staged convergence matrix (small diagnostic, medium, final production), keeping geometry and nuclear data fixed; do not use the smoke-test result as a target.
3. For each stage, record particles, total/inactive batches, seed, OpenMC version, input hashes, `k_eff` and its reported uncertainty, and tally uncertainties.
4. Repeat the final settings with multiple independent seeds. Compare between-run variation to within-run Monte Carlo uncertainty; do not conflate seed spread with physical-model uncertainty.
5. Only compare with a published benchmark value for the same configuration and nuclear-data/solution method. Document differences rather than tuning inputs to force agreement.
6. Obtain an independent review before marking benchmark validation complete.

## Run commands (from the copied model directory)
```bash
cd c5g7-work/c5g7-run
python -c "import openmc; print(openmc.__version__)"
# After confirming the intended cross-section library and reviewed settings:
openmc
```
Do not restore the high-cost production settings blindly; choose them after the staged convergence plan and available compute budget are reviewed.

## Literature/source cross-check
- The OpenMC documentation demonstrates the 2-D C5G7 multigroup model and explains that the benchmark uses macroscopic seven-group cross sections: https://docs.openmc.org/en/v0.12.2/examples/mg-mode-part-i.html
- A public C5G7 overview reports the standard 2-D reference eigenvalue as approximately 1.18655 and describes the 17×17 pin assemblies and quarter-core symmetry: https://github.com/EmreSakarya/c5g7-2d-transport-benchmark
- OECD/NEA explains the C5G7-TD benchmark is based on the steady-state C5G7 problem, with UO2/MOX assemblies and water reflector, but the transient benchmark should not be confused with the steady-state benchmark: https://oecd-nea.org/science/wprs/egrts/c5g7-td/

The reference value near 1.18655 is a **screening comparison only** until the exact configuration, boundary conditions, cross-section library, and reported reference method are matched. The smoke-test result differs by about 0.0496 in k-effective from 1.18655, but the smoke-test uncertainty is large (0.01635); do not infer a meaningful benchmark bias from this run.

## Verdict
**Stage 2 advanced, not passed.** Input discovery, a path portability fix, structural audit, test rerun, and source cross-check are complete. Physics-validation gates remain open because OpenMC could not be run in this environment and exact benchmark-specification/reference comparison is not yet evidenced.

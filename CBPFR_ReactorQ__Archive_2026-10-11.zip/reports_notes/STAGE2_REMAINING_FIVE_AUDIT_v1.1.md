# Stage 2 — Remaining Five Checks: Evidence Audit

Date: 2026-10-10  
Status: **partially completed; physical benchmark gate remains BLOCKED**

This audit distinguishes work that can be completed from the current project bundle from work that requires the user's actual C5G7 model deck, cross-section library provenance, and a runnable OpenMC environment. No missing physics evidence is inferred.

## 1. Model deck versus C5G7 specification

**Status: BLOCKED — deck not included in this bundle.** The package contains no `geometry.xml`, `materials.xml`, `settings.xml`, or statepoint HDF5 files. Therefore no honest line-by-line geometry/material/boundary/tally conformity review or baseline input hash can be made here. A read-only preflight utility was added at `scripts/audit_c5g7_inputs.py`; run it against the actual model directory. Its output is a preflight, not a compliance certificate.

## 2. Nuclear-data provenance

**Status: BLOCKED — evidence absent.** No cross-section HDF5 library or provenance manifest is included in this bundle. The preflight script records whether `OPENMC_CROSS_SECTIONS` points to an existing path, but that alone does not establish library identity, temperature treatment, processing history, or benchmark compatibility. Record the data-library title/version, source URL or DOI, processing code/version, nuclide coverage, temperature treatment, and SHA-256 of the actual library/index files.

## 3. Convergence study and independent seeds

**Status: pilot evidence exists; convergence study incomplete.** The supplied `data/prior_pilot/stage34_results.csv` contains three successful reported runs at 100 batches, 20 inactive batches, and 1,000 particles/batch, with seeds 481730–481732. Their reported k-effective estimates are 1.18354676 ± 0.00266228, 1.18643417 ± 0.00295854, and 1.18952056 ± 0.00291636. Mean across estimates = 1.18650050; sample SD between estimates = 0.00298745. These runs are not independently revalidated here because raw statepoints/logs are absent. Three seeds at one low setting do not constitute a convergence study. Required next run matrix: predeclare multiple increasing particle/batch settings, inspect inactive-batch/source convergence, retain per-run raw logs/statepoints, and assess stability of both estimates and uncertainties.

## 4. Reference comparison

**Status: BLOCKED — no defensible numerical comparison made.** The pilot k-effective values are not compared with a benchmark target because the exact model variant, benchmark quantity definition, nuclear data, and reference-value/uncertainty pairing have not been established from the included evidence. Do not use an arbitrary tolerance or treat overlap of Monte Carlo error bars as proof of benchmark compliance. Once the authorized specification is obtained, preregister the applicable reference quantity, uncertainty convention, comparison statistic, and acceptance criterion before comparing results.

## 5. Independent review

**Status: BLOCKED — not yet performed.** An independent reviewer must check the model-specification mapping, data provenance, source convergence, tally definitions, and reference comparison. A self-audit or passing software tests is not independent review. Record reviewer identity/affiliation, date, exact commit/input hashes reviewed, findings, and resolution evidence.

## Overall decision

The benchmark-selection/design work is complete, and a small repeated-seed pilot is documented. The remaining five checks cannot all be honestly marked complete from the current ZIP: the actual model deck, nuclear-data provenance, raw run artifacts, and independent review evidence are missing. Stage 2 remains **OPEN / BLOCKED for physical validation**. This is an evidence limitation, not a claim that the model is necessarily wrong.

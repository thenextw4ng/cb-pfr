# Experiment note: LP-based safe variable fixing for fuel-like assignment models

## Scope
Synthetic combinatorial assignment benchmarks only; not the Usmanov instance and not a reactor-physics simulation. Each position receives one of three labels with exact label counts. A label is forbidden from appearing on adjacent vertices for labels 1 and 2. Unary and pairwise objective coefficients are random and seeded.

## Mathematical method
Variables x[i,a] represent assigning label a to position i. Pair variables y[i,j,a,b] linearize x[i,a]x[j,b] using McCormick constraints. The LP includes one-hot constraints, exact label counts, and (in the stronger relaxation) y[i,j,a,a]=0 for forbidden adjacent equal labels.

For each candidate assignment x[i,a]=1, solve the LP relaxation conditionally. Let LB[i,a] be its optimal objective and U the objective of any known feasible incumbent. If LB[i,a] > U, then no global optimum can use x[i,a]=1: the LP is a relaxation, so LB is no greater than the best integer objective conditional on that assignment, while the global optimum is no greater than U. Therefore that label choice can be safely fixed to zero.

## Observed results
The 13-cell diamond experiment uses counts (8,4,1), 20 seeded instances, and an incumbent chosen as the best of 50 randomly sampled feasible configurations. There are 108 feasible configurations per instance. The LP including adjacency constraints fixed a mean of 5.15 of 39 cell-label choices, versus 0.70 when adjacency restrictions were omitted from the LP relaxation. No global optimum was excluded in the tested cases.

The 4x4 grid experiment uses counts (9,5,2), 5 seeded instances, and an incumbent chosen as the best of 100 randomly sampled feasible configurations. There are 13,840 feasible configurations per instance. The LP including adjacency constraints fixed a mean of 3.00 of 48 cell-label choices, versus 0.40 when adjacency restrictions were omitted. No global optimum was excluded in the tested cases.

## Interpretation and limitations
The safety property follows from the valid-relaxation argument, not from the finite experiments. The experiments check implementation consistency on the tested instances. This is not evidence of a new algorithm: QUBO preprocessing, persistency, LP relaxations, and variable fixing are established topics. The narrow empirical observation is that explicitly including the adjacency restrictions in this LP relaxation can strengthen safe fixing on these small synthetic cases. The reductions are modest, instances are small, coefficients are random, and no physical objective or hardware annealer was used. The next comparison must include established QUBO preprocessing (e.g., Lewis & Glover 2017 and roof-duality/persistency methods) and scale beyond exact enumeration.

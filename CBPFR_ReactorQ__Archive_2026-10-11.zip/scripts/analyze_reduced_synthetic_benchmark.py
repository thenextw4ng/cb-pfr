#!/usr/bin/env python3
"""Analyze the frozen synthetic ranking experiment without physical claims."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "work" / "matplotlib"))

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt


DEFAULT_INPUT = ROOT / "results" / "reduced_synthetic_benchmark_v1"
DEFAULT_FIGURE = ROOT / "results" / "figures" / "reduced_synthetic_selection.png"


def exact_two_sided_sign_test(left_only: int, right_only: int) -> float:
    """Exact two-sided binomial test for discordant pairs (McNemar form)."""
    trials = left_only + right_only
    if trials == 0:
        return 1.0
    tail = sum(math.comb(trials, value) for value in range(min(left_only, right_only) + 1))
    return min(1.0, 2.0 * tail / (2**trials))


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if not 0 <= successes <= total or total <= 0:
        raise ValueError("invalid binomial count")
    p = successes / total
    denominator = 1.0 + z * z / total
    centre = (p + z * z / (2.0 * total)) / denominator
    radius = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / denominator
    return centre - radius, centre + radius


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--figure", type=Path, default=DEFAULT_FIGURE)
    args = parser.parse_args()
    with (args.input / "per_seed_results.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    methods = ("qubo_only", "point_estimate", "cb_pfr", "uniform_margin")
    by_method = {method: [row for row in rows if row["method"] == method] for method in methods}
    if any(len(values) != 1000 for values in by_method.values()):
        raise ValueError("expected exactly 1,000 prespecified trials per method")
    by_trial = {method: {int(row["trial_index"]): row["selected_true_feasible"] == "True" for row in values}
                for method, values in by_method.items()}
    if any(set(values) != set(range(1000)) for values in by_trial.values()):
        raise ValueError("synthetic trial IDs are incomplete")
    summaries = {}
    for method, values in by_method.items():
        successes = sum(row["selected_true_feasible"] == "True" for row in values)
        summaries[method] = {
            "trials": len(values),
            "successes": successes,
            "selected_true_feasibility_rate": successes / len(values),
            "wilson_95_interval": list(wilson_interval(successes, len(values))),
            "mean_selected_latent_true_response": sum(float(row["selected_latent_true_response"]) for row in values) / len(values),
            "physical_evaluations_per_method": int(values[0]["physical_evaluations_per_method"]),
        }
    paired = {}
    for baseline in ("qubo_only", "point_estimate", "uniform_margin"):
        left_only = sum(by_trial["cb_pfr"][index] and not by_trial[baseline][index] for index in range(1000))
        right_only = sum(by_trial[baseline][index] and not by_trial["cb_pfr"][index] for index in range(1000))
        paired[baseline] = {
            "cb_pfr_minus_baseline_rate": summaries["cb_pfr"]["selected_true_feasibility_rate"] - summaries[baseline]["selected_true_feasibility_rate"],
            "cb_pfr_only_successes": left_only,
            "baseline_only_successes": right_only,
            "exact_two_sided_discordant_pair_p_value": exact_two_sided_sign_test(left_only, right_only),
            "interpretation": "Supplementary paired calculation for the frozen synthetic generator; not a physical effect or an algorithmic novelty claim."
        }
    coverage = json.loads((args.input / "coverage.json").read_text(encoding="utf-8"))
    output = {
        "kind": "synthetic_ranking_analysis",
        "not_physical_validation": True,
        "evidence_level": "software_verification",
        "methods": summaries,
        "paired_comparisons": paired,
        "coverage": coverage,
        "conclusion": "CB-PFR's result is attributable only to this predeclared synthetic known-normal data generator. It does not test a simulator, an actual QUBO-derived physical candidate, or a fuel-loading decision."
    }
    (args.input / "analysis.json").write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.figure.parent.mkdir(parents=True, exist_ok=True)
    labels = ["QUBO\nonly", "Point\nestimate", "CB-PFR", "Uniform\nmargin"]
    rates = [summaries[method]["selected_true_feasibility_rate"] for method in methods]
    intervals = [summaries[method]["wilson_95_interval"] for method in methods]
    lower = [rate - interval[0] for rate, interval in zip(rates, intervals)]
    upper = [interval[1] - rate for rate, interval in zip(rates, intervals)]
    figure, axis = plt.subplots(figsize=(7.2, 4.4), constrained_layout=True)
    colours = ["#7f7f7f", "#4c78a8", "#f58518", "#54a24b"]
    bars = axis.bar(range(len(methods)), rates, yerr=[lower, upper], capsize=4, color=colours)
    for bar, rate in zip(bars, rates):
        axis.text(bar.get_x() + bar.get_width() / 2, rate + 0.006, f"{rate:.3f}", ha="center", va="bottom")
    axis.set_xticks(range(len(methods)), labels)
    axis.set_ylim(0.80, 1.01)
    axis.set_ylabel("Selected latent-true feasibility rate")
    axis.set_title("Synthetic known-normal ranking study (not physical validation)")
    axis.grid(axis="y", alpha=0.25)
    figure.savefig(args.figure, dpi=180)
    plt.close(figure)
    print(json.dumps({"analysis": str(args.input / "analysis.json"), "figure": str(args.figure)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

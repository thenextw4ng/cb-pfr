#!/usr/bin/env python3
"""Create the required top-level tables from preserved final synthetic raw data.

These tables exist because the mandated physical CB-PFR comparison is blocked.
Every record consequently identifies itself as synthetic software evidence;
the script refuses to conceal that boundary.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "results" / "reduced_synthetic_benchmark_v1"
DEFAULT_DESTINATION = ROOT / "results"


def write_rows(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"cannot write empty table: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--destination", type=Path, default=DEFAULT_DESTINATION)
    args = parser.parse_args()
    if not (args.source / "coverage.json").is_file():
        raise FileNotFoundError(f"missing final synthetic coverage artifact: {args.source}")
    args.destination.mkdir(parents=True, exist_ok=True)
    prefix = {
        "evidence_level": "software_verification",
        "experiment_domain": "synthetic_known_normal_model",
        "physical_mapping_status": "NO_DEFENSIBLE_MAPPING_FOUND",
        "physical_validation": "not_performed",
    }
    with (args.source / "per_seed_results.csv").open(encoding="utf-8", newline="") as handle:
        per_seed = [{**prefix, **row} for row in csv.DictReader(handle)]
    with (args.source / "main_results.csv").open(encoding="utf-8", newline="") as handle:
        main = [{**prefix, **row} for row in csv.DictReader(handle)]
    coverage = json.loads((args.source / "coverage.json").read_text(encoding="utf-8"))
    ablation = []
    for baseline, summary in coverage["paired_cb_pfr_minus_baseline"].items():
        ablation.append({
            **prefix,
            "comparison": f"cb_pfr_minus_{baseline}",
            **{key: str(value) for key, value in summary.items()},
        })
    write_rows(args.destination / "per_seed_results.csv", per_seed)
    write_rows(args.destination / "main_results.csv", main)
    write_rows(args.destination / "ablation_results.csv", ablation)
    print(json.dumps({"rows": {"main": len(main), "per_seed": len(per_seed), "ablation": len(ablation)}}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/bin/sh
# Verify the complete archived research evidence, or rerun its frozen studies.
# This script intentionally distinguishes verification of recorded raw MC/DC
# output from the optional costly re-execution of the frozen transport matrix.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
MODE=verify-recorded
WORK_DIR=""
while [ "$#" -gt 0 ]; do
    case "$1" in
        --verify-recorded) MODE=verify-recorded ;;
        --full-transport) MODE=full-transport ;;
        --work-dir)
            shift
            [ "$#" -gt 0 ] || { echo "--work-dir requires a path" >&2; exit 2; }
            WORK_DIR=$1
            ;;
        *) echo "usage: $0 [--verify-recorded|--full-transport] [--work-dir PATH]" >&2; exit 2 ;;
    esac
    shift
done

if [ -n "${CBPFR_PYTHON:-}" ]; then
    :
elif [ -x "$ROOT/.venv/bin/python" ]; then
    CBPFR_PYTHON="$ROOT/.venv/bin/python"
else
    CBPFR_PYTHON=$(command -v python3)
fi
PHYSICAL_PYTHON=${PHYSICAL_PYTHON:-/opt/anaconda3/bin/python}
[ -x "$CBPFR_PYTHON" ] || { echo "CBPFR_PYTHON is not executable: $CBPFR_PYTHON" >&2; exit 2; }
[ -x "$PHYSICAL_PYTHON" ] || { echo "PHYSICAL_PYTHON is not executable: $PHYSICAL_PYTHON" >&2; exit 2; }

if [ -z "$WORK_DIR" ]; then
    WORK_DIR=$(mktemp -d "$ROOT/work/reproducibility.XXXXXX")
elif [ -e "$WORK_DIR" ]; then
    echo "refusing to overwrite existing --work-dir: $WORK_DIR" >&2
    exit 2
else
    mkdir -p "$WORK_DIR"
fi

echo "workspace: $WORK_DIR"
cd "$ROOT"
PYTHONPATH=src "$CBPFR_PYTHON" -m unittest discover -s tests -v
PYTHONPATH=src "$CBPFR_PYTHON" scripts/run_synthetic_pilot.py --results-dir "$WORK_DIR/original_synthetic_pilot"
PYTHONPATH=src "$CBPFR_PYTHON" scripts/run_reduced_synthetic_calibration.py --results-dir "$WORK_DIR/reduced_synthetic"
"$PHYSICAL_PYTHON" scripts/analyze_reduced_synthetic_benchmark.py \
    --input "$WORK_DIR/reduced_synthetic" --figure "$WORK_DIR/reduced_synthetic.png"

if [ "$MODE" = full-transport ]; then
    "$PHYSICAL_PYTHON" physical_simulation_evaluation/scripts/run_c5g7_convergence_study.py \
        --run-root "$WORK_DIR/transport_runs"
    RUN_ROOT="$WORK_DIR/transport_runs"
else
    RUN_ROOT="$ROOT/physical_simulation_evaluation/convergence_study/runs"
fi
"$PHYSICAL_PYTHON" physical_simulation_evaluation/scripts/analyze_c5g7_convergence_study.py \
    --run-root "$RUN_ROOT" \
    --analysis-dir "$WORK_DIR/physical_analysis" \
    --csv "$WORK_DIR/physical_validation_summary.csv"

echo "completed reproducibility mode=$MODE workspace=$WORK_DIR"

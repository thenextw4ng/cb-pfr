#!/usr/bin/env python3
"""Safe one-command C5G7 2-D production run for an existing c5g7-run source tree.
Does not modify or delete anything in the source tree; writes to a new timestamped folder.
Usage: python run_c5g7_openmc_once.py /path/to/c5g7-run [--batches 20000] [--particles 10000] [--inactive 500]
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

OUTPUT_ROOT = Path.home() / "C5G7_openmc_production"

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('source', help='Path to existing c5g7-run folder containing 2d/build-xml-2d.py and mgxs.h5')
    ap.add_argument('--batches', type=int, default=20000)
    ap.add_argument('--particles', type=int, default=10000)
    ap.add_argument('--inactive', type=int, default=500)
    ap.add_argument('--threads', type=int, default=0, help='OpenMP threads; 0 leaves OpenMC default')
    args=ap.parse_args()
    source=Path(args.source).expanduser().resolve()
    builder=source/'2d'/'build-xml-2d.py'
    mgxs=source/'mgxs.h5'
    if not builder.is_file() or not mgxs.is_file():
        sys.exit(f"ERROR: expected {builder} and {mgxs}. Pass the c5g7-run directory, not its parent.")
    if args.batches <= args.inactive or args.inactive < 0 or args.particles < 1:
        sys.exit('ERROR: require batches > inactive >= 0 and particles >= 1.')
    try:
        import openmc
        print(f'OpenMC Python package: {openmc.__version__}')
    except Exception as e:
        sys.exit(f'ERROR: OpenMC Python package unavailable in this environment: {e}\nActivate the environment where `import openmc` works, then rerun this script.')
    exe=shutil.which('openmc')
    if not exe:
        sys.exit('ERROR: `openmc` executable is not on PATH in this environment. Activate the OpenMC environment first.')
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    out=OUTPUT_ROOT/f'c5g7_2d_{stamp}'
    # Copy source tree to a unique output directory, preserving source data and prior runs.
    shutil.copytree(source, out/'c5g7-run', ignore=shutil.ignore_patterns('__pycache__', '*.h5', '*.log', '*.out', 'statepoint.*', 'source.*', 'summary.h5'))
    run_dir=out/'c5g7-run'/'2d'
    # Ensure MGXS file is available at the path expected by the builder, without changing source.
    shutil.copy2(mgxs, out/'c5g7-run'/'mgxs.h5')
    env=os.environ.copy()
    if args.threads:
        env['OMP_NUM_THREADS']=str(args.threads)
    # Build fresh XML inputs in the copied tree only.
    subprocess.run([sys.executable, str(run_dir/'build-xml-2d.py')], cwd=run_dir, env=env, check=True)
    # Patch only the generated settings.xml, preserving the builder's geometry/source/energy mode.
    import xml.etree.ElementTree as ET
    sp=run_dir/'settings.xml'
    tree=ET.parse(sp); root=tree.getroot()
    for tag,val in [('batches',args.batches),('particles',args.particles),('inactive',args.inactive)]:
        node=root.find(tag)
        if node is None:
            node=ET.SubElement(root,tag)
        node.text=str(val)
    tree.write(sp, encoding='utf-8', xml_declaration=True)
    manifest={
      'created_local':dt.datetime.now().astimezone().isoformat(), 'source_tree':str(source), 'output_directory':str(out),
      'openmc_python_version':openmc.__version__, 'openmc_executable':exe,
      'settings':{'run_mode':'eigenvalue','energy_mode':'multi-group','batches':args.batches,'inactive':args.inactive,'particles':args.particles},
      'mgxs_sha256':sha256(out/'c5g7-run'/'mgxs.h5'), 'note':'Fresh copied run tree; source tree was not modified.'
    }
    (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Production simulation starting. Output:', run_dir)
    with (out/'openmc_console.log').open('w') as log:
        subprocess.run([exe], cwd=run_dir, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    states=sorted(run_dir.glob('statepoint.*.h5'))
    if not states:
        sys.exit(f'ERROR: OpenMC exited without a statepoint. Inspect {out}/openmc_console.log')
    spfile=states[-1]
    with openmc.StatePoint(spfile) as statepoint:
        k=statepoint.keff
        result={'statepoint':str(spfile),'keff_mean':float(k.n),'keff_std_dev':float(k.s),'n_batches':int(statepoint.n_batches),'n_particles':int(statepoint.n_particles),'run_mode':statepoint.run_mode}
    (out/'result_summary.json').write_text(json.dumps(result,indent=2))
    print('\nRUN COMPLETED')
    print(json.dumps(result,indent=2))
    print('Evidence folder:',out)

if __name__=='__main__': main()

#!/usr/bin/env python3
"""Fast pilot for stages 3-4: repeated OpenMC eigenvalue runs.
Run from an activated environment with OpenMC installed, in this directory.
This is a diagnostic pilot, not benchmark certification.
"""
from pathlib import Path
import csv, json, shutil, subprocess, sys, time, xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
OUT = BASE / "stage34_runs"
N_RUNS = 3
BATCHES = 100
INACTIVE = 20
PARTICLES = 1000
SEED_BASE = 481730
INPUTS = ["geometry.xml", "materials.xml", "settings.xml", "tallies.xml", "mgxs.h5"]

if shutil.which("openmc") is None:
    sys.exit("ERROR: openmc executable not found. Activate the OpenMC conda environment, then rerun.")
for name in INPUTS:
    if not (BASE / name).exists():
        sys.exit(f"ERROR: missing {name} in {BASE}")

OUT.mkdir(exist_ok=True)
results = []
for i in range(N_RUNS):
    run_dir = OUT / f"run_{i+1:02d}"
    run_dir.mkdir(exist_ok=True)
    for name in INPUTS:
        shutil.copy2(BASE / name, run_dir / name)
    # Ensure the multigroup library path works even if this project folder was moved.
    materials = run_dir / "materials.xml"
    tree = ET.parse(materials)
    cs = tree.getroot().find("cross_sections")
    if cs is not None:
        cs.text = str((BASE / "mgxs.h5").resolve())
        tree.write(materials, encoding="utf-8", xml_declaration=True)
    settings_path = run_dir / "settings.xml"
    st = ET.parse(settings_path)
    root = st.getroot()
    for tag, val in [("batches", BATCHES), ("inactive", INACTIVE), ("particles", PARTICLES)]:
        node = root.find(tag)
        if node is None:
            node = ET.SubElement(root, tag)
        node.text = str(val)
    st.write(settings_path, encoding="utf-8", xml_declaration=True)
    seed = SEED_BASE + i
    log = run_dir / "openmc.log"
    print(f"[{i+1}/{N_RUNS}] Running {BATCHES} batches × {PARTICLES} particles (seed {seed})...", flush=True)
    start = time.time()
    with log.open("w") as f:
        proc = subprocess.run(["openmc", "-s", str(seed)], cwd=run_dir, stdout=f, stderr=subprocess.STDOUT)
    elapsed = round(time.time() - start, 1)
    if proc.returncode != 0:
        print(f"Run {i+1} failed. See {log}", file=sys.stderr)
        results.append({"run": i+1, "seed": seed, "status": "FAILED", "seconds": elapsed})
        continue
    statepoints = sorted(run_dir.glob("statepoint.*.h5"))
    if not statepoints:
        results.append({"run": i+1, "seed": seed, "status": "NO_STATEPOINT", "seconds": elapsed})
        continue
    try:
        import openmc
        with openmc.StatePoint(str(statepoints[-1])) as sp:
            k = sp.keff
            mean = float(k.nominal_value)
            sd = float(k.std_dev)
        results.append({"run": i+1, "seed": seed, "status": "OK", "batches": BATCHES,
                        "inactive": INACTIVE, "particles": PARTICLES, "keff": mean,
                        "keff_std_dev": sd, "seconds": elapsed, "statepoint": str(statepoints[-1].relative_to(BASE))})
        print(f"    keff = {mean:.6f} +/- {sd:.6f}; {elapsed}s", flush=True)
    except Exception as e:
        results.append({"run": i+1, "seed": seed, "status": "ANALYSIS_ERROR", "error": str(e), "seconds": elapsed})

ok = [r for r in results if r.get("status") == "OK"]
if ok:
    vals = [r["keff"] for r in ok]
    mean = sum(vals) / len(vals)
    sd_between = (sum((x-mean)**2 for x in vals)/(len(vals)-1))**0.5 if len(vals) > 1 else None
    summary = {"purpose": "Stage 3-4 exploratory repeated-run pilot; not benchmark validation",
               "runs_requested": N_RUNS, "runs_successful": len(ok), "settings": {"batches": BATCHES, "inactive": INACTIVE, "particles": PARTICLES},
               "keff_mean_across_runs": mean, "keff_sd_between_runs": sd_between,
               "runs": results,
               "interpretation": "Compare between-run spread with each run's reported uncertainty. If spread is large or any run fails, inspect convergence and model configuration before production runs."}
else:
    summary = {"purpose": "Stage 3-4 exploratory repeated-run pilot; not benchmark validation", "runs_requested": N_RUNS, "runs_successful": 0, "runs": results}
(OUT / "stage34_summary.json").write_text(json.dumps(summary, indent=2))
with (OUT / "stage34_results.csv").open("w", newline="") as f:
    fields = sorted({k for r in results for k in r})
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(results)
print(f"\nDone. Summary: {OUT / 'stage34_summary.json'}")
print(f"CSV: {OUT / 'stage34_results.csv'}")
print("NOTE: this 3-run pilot is for checking reproducibility/workflow, not final statistical or benchmark validation.")

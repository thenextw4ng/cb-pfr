#!/usr/bin/env python3
"""Run three independent OpenMC C5G7 pilot simulations with explicit per-run seeds."""
from pathlib import Path
import os, shutil, subprocess, csv, json, time
import xml.etree.ElementTree as ET
import openmc

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "stage34_runs"
SEEDS = [481730, 481731, 481732]
BATCHES, INACTIVE, PARTICLES = 100, 20, 1000

if shutil.which("openmc") is None:
    raise SystemExit("ERROR: executable 'openmc' not found. Activate openmc-env first.")

required = ["geometry.xml", "materials.xml", "settings.xml", "tallies.xml", "mgxs.h5"]
missing = [f for f in required if not (ROOT / f).exists()]
if missing:
    raise SystemExit("ERROR: missing files in project folder: " + ", ".join(missing))

OUT.mkdir(exist_ok=True)
results = []
for i, seed in enumerate(SEEDS, 1):
    run_dir = OUT / f"run_{i:02d}"
    if run_dir.exists():
        shutil.rmtree(run_dir)
    run_dir.mkdir()
    for name in required:
        shutil.copy2(ROOT / name, run_dir / name)

    # Patch local MGXS path to this run folder.
    mat = run_dir / "materials.xml"
    txt = mat.read_text()
    txt = txt.replace("/Users/catur/c5g7-work/c5g7-run/mgxs.h5", str((run_dir / "mgxs.h5").resolve()))
    mat.write_text(txt)

    # Write a unique seed explicitly into settings.xml; do not pass seed as CLI -s.
    settings_path = run_dir / "settings.xml"
    tree = ET.parse(settings_path)
    root = tree.getroot()
    for tag, value in [("batches", BATCHES), ("inactive", INACTIVE), ("particles", PARTICLES), ("seed", seed)]:
        el = root.find(tag)
        if el is None:
            el = ET.SubElement(root, tag)
        el.text = str(value)
    tree.write(settings_path, encoding="utf-8", xml_declaration=True)

    print(f"[{i}/3] Running {BATCHES} batches × {PARTICLES} particles (explicit seed {seed})...", flush=True)
    start = time.time()
    env = {**os.environ, "OMP_NUM_THREADS": "2"}
    log_path = run_dir / "openmc.log"
    with log_path.open("w") as log:
        proc = subprocess.run(["openmc"], cwd=run_dir, env=env, stdout=log, stderr=subprocess.STDOUT)
    elapsed = round(time.time() - start, 2)
    statepoint = run_dir / f"statepoint.{BATCHES}.h5"
    if proc.returncode != 0 or not statepoint.exists():
        print(f"Run {i} FAILED; inspect {log_path}", flush=True)
        results.append(dict(run=i, seed=seed, status="FAILED", seconds=elapsed, error_log=str(log_path)))
        continue
    try:
        with openmc.StatePoint(str(statepoint)) as sp:
            k = sp.keff
            kval = float(k.nominal_value)
            ksd = float(k.std_dev)
        status = "OK"
        print(f"    keff = {kval:.6f} +/- {ksd:.6f}; {elapsed}s", flush=True)
        results.append(dict(run=i, seed=seed, status=status, batches=BATCHES, inactive=INACTIVE,
                            particles=PARTICLES, keff=kval, keff_std_dev=ksd, seconds=elapsed,
                            statepoint=str(statepoint.relative_to(ROOT))))
    except Exception as e:
        print(f"Run {i} result-read FAILED: {e}", flush=True)
        results.append(dict(run=i, seed=seed, status="READ_FAILED", seconds=elapsed, error=str(e)))

oks = [r for r in results if r.get("status") == "OK"]
summary = {
    "purpose": "Exploratory repeated-run pilot with explicit unique OpenMC seeds; not benchmark validation",
    "runs_requested": len(SEEDS), "runs_successful": len(oks),
    "settings": {"batches": BATCHES, "inactive": INACTIVE, "particles": PARTICLES},
    "keff_mean_across_runs": (sum(r["keff"] for r in oks)/len(oks)) if oks else None,
    "keff_sd_between_runs": (float(__import__("statistics").stdev(r["keff"] for r in oks)) if len(oks)>1 else None),
    "runs": results,
    "interpretation": "Verify unique seeds and compare between-run spread with reported uncertainty. This pilot alone is not physical or benchmark validation."
}
(OUT / "stage34_summary.json").write_text(json.dumps(summary, indent=2))
if results:
    fields = sorted(set().union(*(r.keys() for r in results)))
    with (OUT / "stage34_results.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(results)
print(f"Done. Summary: {OUT / 'stage34_summary.json'}")
print(f"CSV: {OUT / 'stage34_results.csv'}")

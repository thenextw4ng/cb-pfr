#!/usr/bin/env python3
"""Execute the non-physical CB-PFR method-verification pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cbpfr.openmc import preflight_openmc, write_candidate_manifest
from cbpfr.qubo import CoreSpec, build_usmanov_style_qubo, enumerate_feasible_candidates
from cbpfr.synthetic import run_synthetic_pilot, write_synthetic_results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--core", type=Path, default=ROOT / "config" / "toy_core_7.json")
    parser.add_argument("--config", type=Path, default=ROOT / "config" / "synthetic_pilot.json")
    parser.add_argument("--results-dir", type=Path, default=ROOT / "results")
    args = parser.parse_args()

    spec = CoreSpec.from_json(args.core)
    model = build_usmanov_style_qubo(spec)
    config = json.loads(args.config.read_text(encoding="utf-8"))
    records, summary = run_synthetic_pilot(model, config)
    args.results_dir.mkdir(parents=True, exist_ok=True)
    raw_path, summary_path = write_synthetic_results(records, summary, args.results_dir)
    candidates = enumerate_feasible_candidates(model)
    manifest = write_candidate_manifest(model, candidates[0], args.results_dir / "example_candidate_manifest.json")
    preflight = preflight_openmc(ROOT / "openmc_model")
    preflight_path = args.results_dir / "openmc_preflight.json"
    preflight_path.write_text(json.dumps(preflight.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    run_metadata = {
        "core_config_sha256": hashlib.sha256(args.core.read_bytes()).hexdigest(),
        "pilot_config_sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
        "feasible_toy_candidates": len(candidates),
        "example_manifest_status": manifest["status"],
        "openmc_preflight_status": preflight.status,
        "not_physical_validation": True,
    }
    metadata_path = args.results_dir / "run_metadata.json"
    metadata_path.write_text(json.dumps(run_metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {raw_path}")
    print(f"wrote {summary_path}")
    print(f"wrote {preflight_path}")
    print(f"wrote {metadata_path}")
    print(f"OpenMC preflight: {preflight.status}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
